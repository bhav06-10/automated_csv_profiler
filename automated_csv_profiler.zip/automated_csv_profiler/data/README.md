# Data

The raw CSV files are **not committed**. They are 78 MB and 38 MB, which is too large for a clean GitHub/Canvas submission, and both are freely downloadable. Download them into this folder with the exact file names below; `.gitignore` excludes `data/*.csv`.

## Dataset A: `ev_population_data.csv` (development dataset)

- **Organization:** Washington State Department of Licensing (DOL), published on Data.WA
- **Title:** Electric Vehicle Population Data
- **Source:** https://data.wa.gov/Transportation/Electric-Vehicle-Population-Data/f6w7-q2d2 (catalog entry: https://catalog.data.gov/dataset/electric-vehicle-population-data)
- **Copy used:** `20260126_Electric_Vehicle_Population_Data.csv` from the CSCI 5502 Canvas module "Workshop - EV Data Analysis", renamed to `ev_population_data.csv`
- **Date accessed:** 2026-09-28
- **Shape:** 299,705 rows × 16 columns
- **How to download:** the Canvas file, or on Data.WA choose Export → CSV. A newer export may have a different row count.

## Dataset B: `nyserda_uer_county_monthly.csv` (new dataset)

- **Organization:** New York State Energy Research and Development Authority (NYSERDA), published on data.ny.gov
- **Title:** Utility Energy Registry Monthly County Energy Use: Beginning 2021
- **Source:** https://data.ny.gov/Energy-Environment/Utility-Energy-Registry-Monthly-County-Energy-Use-/46pe-aat9
- **Data dictionary:** `NYSERDA_UERCountyMonthlyData_DataDictionary.pdf` (Attachments section of the page above)
- **Date accessed:** 2026-09-28 (exported file `Utility_Energy_Registry_Monthly_County_Energy_Use__Beginning_2021_20260928.csv`, renamed)
- **Shape:** 299,662 rows × 14 columns
- **License:** listed as unspecified on the portal
- **How to download:** Export → CSV, then rename the file to `nyserda_uer_county_monthly.csv`

## Why Dataset B has a noticeably different structure

| | Dataset A | Dataset B |
|---|---|---|
| Main content | vehicle registrations: categorical text | utility energy metrics: numeric values |
| Numeric measures | 1 (`Electric Range`) | 2 (`value`, `number_of_accounts`) |
| Numbers stored as codes | ZIP, district, census tract, vehicle ID | FIPS code, utility ID |
| Number formatting | plain | thousands separators ("12,700,000") |
| Missing-value coding | blanks only | blanks and `-999` (withheld for privacy, per the data dictionary) |
| Time dimension | model year only | year + month (monthly series) |
| Units | single | mixed MW / MWh / Therms in a `unit` column |
| Location fields | coordinates, ZIP, census tract | county only |

The profiler was run on Dataset B **without any change to the analysis code**: only `--csv` and `--name` changed.

## Note on documentation vs. automated output

The data dictionary explains that `-999` means *withheld for privacy* and that blank `value` cells mean *not reported*. The program does **not** read the PDF. It independently flags `-999` as a "possible code for missing or withheld data" and states that the code's meaning is not documented in the file. The dictionary is cited here only so a human reader can confirm the flag.
