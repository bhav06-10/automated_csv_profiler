"""
quality.py - Automatic data-quality checks. Everything here FLAGS; nothing edits,
drops or imputes data. Each check returns plain dicts that go straight into
analysis_summary.json and the report.
"""
import re

import numpy as np
import pandas as pd

from inference import (GEOMETRY_RE, LATLON_RE, ROLE_CATEGORICAL, ROLE_ID, ROLE_NUMERIC,
                       ROLE_TEXT, ROLE_UNKNOWN)
from utils import name_tokens, pct

VALUE_PATTERNS = {
    "email address": re.compile(r"[\w.+-]+@[\w-]+\.[A-Za-z]{2,}"),
    "phone number": re.compile(r"(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]\d{3}[-.\s]\d{4}\b"),
    "US social security number": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "IP address": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
}
DISCLAIMER = ("The sensitive-field check is only a heuristic based on column names and a "
              "few value patterns. The absence of a warning does NOT mean the dataset is safe "
              "or free of personal information.")


def _sensitive_by_name(col, cfg):
    tokens = set(name_tokens(col))
    hits = sorted(tokens & set(cfg["sensitive_name_tokens"]))
    if "name" in tokens:
        others = tokens - {"name", "names"}
        if not others or others & set(cfg["person_name_qualifiers"]):
            hits.append("name")
    return hits


def _sensitive_by_value(raw, cfg):
    nonnull = raw.dropna().astype(str)
    if nonnull.empty:
        return []
    n = min(len(nonnull), cfg["inference_sample_size"])
    sample = nonnull.sample(n=n, random_state=cfg["random_seed"]) if len(nonnull) > n else nonnull
    found = []
    patterns = dict(VALUE_PATTERNS)
    for label, regex in patterns.items():
        m = int(sample.str.contains(regex).sum())
        if m >= cfg["sensitive_min_matches"] or (m and m / len(sample) >= 0.10):
            found.append({"pattern": label, "matches_in_sample": m, "sample_size": int(len(sample))})
    geo = int((sample.str.match(GEOMETRY_RE) | sample.str.match(LATLON_RE)).sum())
    if geo >= cfg["sensitive_min_matches"] or (geo and geo / len(sample) >= 0.10):
        found.append({"pattern": "geographic coordinates", "matches_in_sample": geo,
                      "sample_size": int(len(sample))})
    return found


def _case_variants(raw, max_groups=5):
    """Categories that differ only by letter case or spacing, e.g. 'MWh' vs 'MWH'."""
    counts = raw.dropna().value_counts()
    if counts.empty:
        return []
    norm = pd.Series(counts.index.astype(str), index=counts.index).str.strip().str.lower() \
        .str.replace(r"\s+", " ", regex=True)
    groups = []
    for key, idx in norm.groupby(norm).groups.items():
        if len(idx) > 1:
            variants = {str(v): int(counts[v]) for v in idx}
            groups.append({"normalized": key, "variants": variants})
    groups.sort(key=lambda g: -sum(g["variants"].values()))
    return groups[:max_groups]


def run_quality_checks(raw_df, profiles, typed, cfg):
    n_rows = len(raw_df)
    prof_by_col = {p["column"]: p for p in profiles}
    q = {"thresholds": {"high_missing_pct": cfg["high_missing_pct"],
                        "high_cardinality_count": cfg["high_cardinality_count"],
                        "high_cardinality_ratio": cfg["high_cardinality_ratio"],
                        "dominant_category_pct": cfg["dominant_category_pct"],
                        "zero_inflation_pct": cfg["zero_inflation_pct"]}}

    # 1. Duplicate rows (exact match across every column, on the raw text)
    n_dup = int(raw_df.duplicated().sum()) if n_rows else 0
    q["duplicate_rows"] = {"count": n_dup, "pct": pct(n_dup, n_rows)}

    # 2. Missingness
    missing = [{"column": p["column"], "missing": p["missing"], "missing_pct": p["missing_pct"]}
               for p in profiles if p["missing"] > 0]
    missing.sort(key=lambda d: -d["missing_pct"])
    q["missing_by_column"] = missing
    q["total_missing_cells"] = int(sum(d["missing"] for d in missing))
    q["total_missing_cells_pct"] = pct(q["total_missing_cells"], n_rows * max(len(profiles), 1))
    q["high_missing_columns"] = [d for d in missing if d["missing_pct"] >= cfg["high_missing_pct"]]
    q["rows_with_any_missing"] = int(raw_df.isna().any(axis=1).sum()) if n_rows else 0
    q["rows_with_any_missing_pct"] = pct(q["rows_with_any_missing"], n_rows)

    # 3. Constant / empty columns
    q["empty_columns"] = [p["column"] for p in profiles if p["non_missing"] == 0]
    q["constant_columns"] = [{"column": p["column"], "value": str(raw_df[p["column"]].dropna().iloc[0]),
                              "missing_pct": p["missing_pct"]}
                             for p in profiles if p["n_unique"] == 1]

    # 4. Mixed or inconsistent types / formats
    mixed = []
    for p in profiles:
        col = p["column"]
        issues = []
        if p["role"] == ROLE_UNKNOWN and p["technical_type"].startswith("mixed"):
            issues.append(p["reason"])
        if p.get("unparsed_values"):
            issues.append(f"{p['unparsed_values']:,} values do not match the column's inferred type")
        issues += [n for n in p["notes"] if "were parsed as numbers" in n]
        if p.get("multi_valued"):
            issues.append("some values contain list delimiters ('|' or ';')")
        variants = _case_variants(raw_df[col]) if p["role"] in (ROLE_CATEGORICAL, ROLE_UNKNOWN) \
            and p["n_unique"] <= 5000 else []
        if variants:
            issues.append("categories that differ only by letter case or spacing: " +
                          "; ".join(" / ".join(f"'{k}' ({v:,})" for k, v in g["variants"].items())
                                    for g in variants))
        if raw_df[col].dtype != "float64" and p["non_missing"]:
            s = raw_df[col].dropna().astype(str)
            ws = int((s != s.str.strip()).sum())
            if ws:
                issues.append(f"{ws:,} values have leading/trailing spaces")
        if issues:
            mixed.append({"column": col, "issues": issues, "case_variants": variants})
    q["mixed_or_inconsistent"] = mixed

    # 5. Identifier-like and high-cardinality columns
    q["identifier_like_columns"] = [{"column": p["column"], "n_unique": p["n_unique"],
                                     "unique_ratio": p["unique_ratio"], "reason": p["reason"]}
                                    for p in profiles if p["role"] == ROLE_ID]
    q["high_cardinality_columns"] = [
        {"column": p["column"], "n_unique": p["n_unique"], "unique_ratio": p["unique_ratio"]}
        for p in profiles if p["role"] in (ROLE_CATEGORICAL, ROLE_TEXT)
        and (p["n_unique"] > cfg["high_cardinality_count"] or p["unique_ratio"] > cfg["high_cardinality_ratio"])]

    # 6. Potentially sensitive fields
    sensitive = []
    for p in profiles:
        col = p["column"]
        by_name = _sensitive_by_name(col, cfg)
        by_value = _sensitive_by_value(raw_df[col], cfg) if p["role"] != ROLE_NUMERIC else []
        if by_name or by_value:
            sensitive.append({"column": col, "name_keywords": by_name, "value_patterns": by_value})
    q["potentially_sensitive"] = sensitive
    q["sensitive_disclaimer"] = DISCLAIMER

    # 7. Extra checks: dominant categories, sentinel codes, zero inflation, disguised missing
    dominant, sentinels, zero_inflated, disguised = [], [], [], []
    tokens = set(cfg["disguised_missing_tokens"])
    for p in profiles:
        col, role = p["column"], p["role"]
        if role in (ROLE_CATEGORICAL,) and p["non_missing"] and p["n_unique"] > 1:
            vc = raw_df[col].value_counts()
            share = pct(vc.iloc[0], p["non_missing"])
            if share >= cfg["dominant_category_pct"]:
                dominant.append({"column": col, "value": str(vc.index[0]), "count": int(vc.iloc[0]),
                                 "pct_of_non_missing": share})
        if role == ROLE_NUMERIC:
            s = typed[col].dropna()
            if len(s):
                for code in cfg["sentinel_values"]:
                    c = int((s == code).sum())
                    if c and (code in (s.min(), s.max())) and pct(c, len(s)) >= cfg["sentinel_min_pct"]:
                        sentinels.append({"column": col, "value": code, "count": c,
                                          "pct_of_non_missing": pct(c, len(s))})
                z = int((s == 0).sum())
                if pct(z, len(s)) >= cfg["zero_inflation_pct"]:
                    zero_inflated.append({"column": col, "zero_count": z, "zero_pct": pct(z, len(s))})
        if role in (ROLE_CATEGORICAL, ROLE_TEXT, ROLE_UNKNOWN) and p["non_missing"]:
            s = raw_df[col].dropna().astype(str).str.strip().str.lower()
            hits = s[s.isin(tokens)]
            if len(hits):
                disguised.append({"column": col, "count": int(len(hits)),
                                  "pct": pct(len(hits), n_rows),
                                  "tokens": {k: int(v) for k, v in hits.value_counts().items()}})
    q["dominant_categories"] = dominant
    q["possible_sentinel_codes"] = sentinels
    q["zero_inflated_columns"] = zero_inflated
    q["disguised_missing_tokens"] = disguised

    # Unit-of-measure columns: numeric summaries may mix units.
    unit_cols = []
    for p in profiles:
        if p["role"] == ROLE_CATEGORICAL and set(name_tokens(p["column"])) & set(cfg["unit_name_tokens"]) \
                and p["n_unique"] > 1:
            unit_cols.append({"column": p["column"], "n_unique": p["n_unique"],
                              "values": {str(k): int(v) for k, v in
                                         raw_df[p["column"]].value_counts().head(10).items()}})
    q["unit_columns"] = unit_cols

    q["policy"] = ("No rows, values or outliers were deleted, imputed or modified. All issues "
                   "below are flags for a human to review.")
    return q
