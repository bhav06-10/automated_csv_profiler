"""
viz.py - Adaptive visualisations.

Plots are *planned* from the inferred column roles, ranked by priority, capped at
cfg['max_plots'], then rendered. Every plot type that is not produced gets a
written reason in `skipped`, so the report never silently omits a chart.
"""
import matplotlib

matplotlib.use("Agg")                     # file output only; no display needed
import matplotlib.pyplot as plt          # noqa: E402
import matplotlib.ticker                  # noqa: E402
import textwrap                          # noqa: E402
import numpy as np                       # noqa: E402
import pandas as pd                      # noqa: E402
from matplotlib.colors import LinearSegmentedColormap  # noqa: E402

from inference import ROLE_BOOLEAN, ROLE_CATEGORICAL   # noqa: E402
from utils import truncate                             # noqa: E402

PRIMARY = "#2a78d6"      # single-series colour
ACCENT = "#eb6834"       # reference lines / highlights
MUTED = "#a3a29c"        # "Other" bucket
INK, INK2 = "#1f1f1e", "#52514e"
GRID = "#e6e5e0"
DIVERGING = LinearSegmentedColormap.from_list("div", [PRIMARY, "#f0efec", ACCENT])

plt.rcParams.update({
    "figure.facecolor": "white", "axes.facecolor": "white", "savefig.facecolor": "white",
    "axes.edgecolor": INK2, "axes.labelcolor": INK, "xtick.color": INK2, "ytick.color": INK2,
    "axes.titlesize": 12, "axes.titleweight": "bold", "axes.labelsize": 10, "font.size": 9.5,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": GRID, "grid.linewidth": 0.8,
})


# ------------------------------------------------------------------ helpers
def _log_view(s, cfg):
    """Decide whether a numeric series should be drawn on a log10(x+1) axis."""
    s = s.dropna()
    if len(s) < 3:
        return False
    skew = s.skew()
    return bool(pd.notna(skew) and abs(skew) > cfg["skew_log_threshold"] and (s >= 0).mean() > 0.5)


def _transform(s, log):
    """Return (values_to_plot, n_hidden). Negative values cannot be shown on a log axis."""
    s = s.dropna()
    if not log:
        return s, 0
    keep = s[s >= 0]
    return np.log10(keep + 1), int(len(s) - len(keep))


def _axis_label(col, log):
    return f"{truncate(col, 40)} (log scale)" if log else truncate(col, 40)


NICE = [0, 1, 2, 5, 10, 20, 50, 100, 200, 500, 1_000, 2_000, 5_000, 10_000, 20_000, 50_000, 100_000,
        200_000, 500_000, 1_000_000, 2_000_000, 5_000_000, 10_000_000, 20_000_000, 50_000_000,
        100_000_000, 200_000_000, 500_000_000, 1_000_000_000]


def _short(v):
    for div, suf in ((1e9, "B"), (1e6, "M"), (1e3, "k")):
        if abs(v) >= div:
            return f"{v / div:g}{suf}"
    return f"{v:g}"


def _log_ticks(ax, max_value, axis="x"):
    """Label a log10(x+1) axis with the original values (0, 1, 10, 100, ...)."""
    ticks = [v for v in NICE if v <= max(max_value, 1) * 1.05]
    if len(ticks) > 9:                       # thin out: keep 1-10-100 style ticks
        ticks = [v for v in ticks if v == 0 or str(v).lstrip("-")[0] == "1"]
    pos = [np.log10(v + 1) for v in ticks]
    labels = [_short(v) for v in ticks]
    (ax.set_xticks if axis == "x" else ax.set_yticks)(pos, labels)


def _thousands(ax, axis="x"):
    fmt = matplotlib.ticker.FuncFormatter(lambda v, _: f"{v:,.0f}")
    (ax.xaxis if axis == "x" else ax.yaxis).set_major_formatter(fmt)


def _title(ax, text, width=62, **kw):
    ax.set_title(textwrap.fill(text, width), **kw)


def _save(fig, path):
    fig.tight_layout()
    fig.savefig(path, dpi=120)
    plt.close(fig)


# ------------------------------------------------------------------ plot types
def plot_missing(ctx, path):
    prof = [p for p in ctx["profiles"] if p["missing"] > 0]
    prof.sort(key=lambda p: p["missing_pct"])
    prof = prof[-20:]
    fig, ax = plt.subplots(figsize=(9, max(3, 0.38 * len(prof) + 1.5)))
    labels = [truncate(p["column"], ctx["cfg"]["label_max_chars"]) for p in prof]
    vals = [p["missing_pct"] for p in prof]
    ax.barh(labels, vals, color=PRIMARY, height=0.6)
    for y, (v, p) in enumerate(zip(vals, prof)):
        ax.text(v, y, f"  {v:.2f}% ({p['missing']:,})", va="center", fontsize=8.5, color=INK2)
    thr = ctx["cfg"]["high_missing_pct"]
    ax.axvline(thr, color=ACCENT, ls="--", lw=1.2, label=f"high-missing threshold ({thr:g}%)")
    ax.set_xlim(0, max(max(vals) * 1.35, thr * 1.1))
    ax.set_xlabel("Missing values (% of all rows)")
    ax.set_ylabel("Column")
    ax.set_title(f"Missing values by column ({len(prof)} of {len(ctx['profiles'])} columns have gaps)")
    ax.legend(loc="best", frameon=True, framealpha=0.9)
    ax.grid(axis="y", visible=False)
    _save(fig, path)


def plot_categorical(ctx, path, col):
    s = ctx["raw_df"][col].dropna()
    vc = s.value_counts()
    top_n = ctx["cfg"]["top_n_categories"]
    top = vc.head(top_n)
    labels = [truncate(v, ctx["cfg"]["label_max_chars"]) for v in top.index]
    values = top.tolist()
    colors = [PRIMARY] * len(values)
    if len(vc) > top_n:
        labels.append(f"Other ({len(vc) - top_n:,} categories)")
        values.append(int(vc.iloc[top_n:].sum()))
        colors.append(MUTED)
    labels, values, colors = labels[::-1], values[::-1], colors[::-1]
    fig, ax = plt.subplots(figsize=(9, max(3.2, 0.42 * len(values) + 1.5)))
    ax.barh(labels, values, color=colors, height=0.6)
    total = len(s)
    for y, v in enumerate(values):
        ax.text(v, y, f"  {v:,} ({100 * v / total:.1f}%)", va="center", fontsize=8.5, color=INK2)
    ax.set_xlim(0, max(values) * 1.3)
    ax.set_xlabel("Number of rows")
    ax.set_ylabel("Category")
    _thousands(ax, "x")
    shown = "all" if len(vc) <= top_n else f"top {top_n} of {len(vc):,}"
    _title(ax, f"Most frequent values of '{col}' ({shown} categories)")
    ax.grid(axis="y", visible=False)
    _save(fig, path)


def plot_histogram(ctx, path, col):
    s = ctx["typed"][col]
    log = _log_view(s, ctx["cfg"])
    vals, hidden = _transform(s, log)
    fig, ax = plt.subplots(figsize=(9, 5))
    ax.hist(vals, bins=50, color=PRIMARY, edgecolor="white", linewidth=0.4)
    st = ctx["stats"]["numeric"][col]
    med = np.log10(st["median"] + 1) if log and st["median"] >= 0 else st["median"]
    ax.axvline(med, color=ACCENT, lw=1.5, ls="--", label=f"median = {st['median']:,}")
    ax.set_xlabel(_axis_label(col, log))
    ax.set_ylabel("Number of rows")
    _thousands(ax, "y")
    if log:
        _log_ticks(ax, st["max"])
    title = f"Distribution of '{col}'"
    if log:
        title += " (log scale - strongly right-skewed)"
    _title(ax, title)
    if hidden:
        ax.text(0.99, 0.95, f"{hidden:,} negative values not shown on log axis",
                transform=ax.transAxes, ha="right", fontsize=8.5, color=INK2)
    ax.legend(frameon=False, loc="upper right" if not hidden else "center right")
    _save(fig, path)


def plot_boxplots(ctx, path, cols):
    fig, axes = plt.subplots(len(cols), 1, figsize=(9, 1.9 * len(cols) + 1.2), squeeze=False)
    for ax, col in zip(axes[:, 0], cols):
        s = ctx["typed"][col]
        log = _log_view(s, ctx["cfg"])
        vals, hidden = _transform(s, log)
        ax.boxplot(vals, vert=False, widths=0.5, patch_artist=True,
                   boxprops=dict(facecolor="#d6e4f7", edgecolor=PRIMARY),
                   medianprops=dict(color=ACCENT, lw=2),
                   whiskerprops=dict(color=PRIMARY), capprops=dict(color=PRIMARY),
                   flierprops=dict(marker="o", markersize=2.5, markerfacecolor=PRIMARY,
                                   markeredgecolor="none", alpha=0.25))
        st = ctx["stats"]["numeric"][col]
        if log:
            _log_ticks(ax, st["max"])
        ax.set_yticks([1], [truncate(col, 24)])
        ax.set_xlabel(_axis_label(col, log) + (f"   ({hidden:,} negative values hidden)" if hidden else ""))
        ax.set_title(f"{truncate(col, 40)}: {st['outlier_count']:,} outliers "
                     f"({st['outlier_pct']}%) by the 1.5×IQR rule", fontsize=10.5)
    fig.suptitle("Boxplots of numeric measures (points = potential outliers, not removed)",
                 fontweight="bold", fontsize=12)
    _save(fig, path)


def plot_corr_heatmap(ctx, path):
    rel = ctx["relationships"]
    cols = rel["measures_used"]
    m = pd.DataFrame(rel["pearson_matrix"]).loc[cols, cols].astype(float)
    fig, ax = plt.subplots(figsize=(1.0 * len(cols) + 4, 0.85 * len(cols) + 3))
    im = ax.imshow(m.values, cmap=DIVERGING, vmin=-1, vmax=1)
    labels = [truncate(c, 20) for c in cols]
    ax.set_xticks(range(len(cols)), labels, rotation=40, ha="right")
    ax.set_yticks(range(len(cols)), labels)
    for i in range(len(cols)):
        for j in range(len(cols)):
            v = m.values[i, j]
            if not np.isnan(v):
                ax.text(j, i, f"{v:.2f}", ha="center", va="center", fontsize=8.5, color=INK)
    ax.grid(False)
    ax.set_xlabel("Numeric measure")
    ax.set_ylabel("Numeric measure")
    fig.colorbar(im, ax=ax, label="Pearson correlation (r)", shrink=0.8)
    ax.set_title("Correlation matrix of numeric measures (Pearson r)")
    _save(fig, path)


def plot_scatter(ctx, path, pair):
    a, b = pair["col_a"], pair["col_b"]
    df = pd.DataFrame({a: ctx["typed"][a], b: ctx["typed"][b]}).dropna()
    n = ctx["cfg"]["scatter_sample_size"]
    sampled = len(df) > n
    if sampled:
        df = df.sample(n=n, random_state=ctx["cfg"]["random_seed"])
    la, lb = _log_view(df[a], ctx["cfg"]), _log_view(df[b], ctx["cfg"])
    if la:
        df = df[df[a] >= 0]
    if lb:
        df = df[df[b] >= 0]
    x = np.log10(df[a] + 1) if la else df[a]
    y = np.log10(df[b] + 1) if lb else df[b]
    fig, ax = plt.subplots(figsize=(8, 6))
    ax.scatter(x, y, s=10, color=PRIMARY, alpha=0.35, edgecolors="none")
    ax.set_xlabel(_axis_label(a, la))
    ax.set_ylabel(_axis_label(b, lb))
    if la:
        _log_ticks(ax, df[a].max(), "x")
    if lb:
        _log_ticks(ax, df[b].max(), "y")
    ax.set_title(f"'{truncate(a, 30)}' vs '{truncate(b, 30)}'\n"
                 f"Pearson r = {pair['pearson_r']}, Spearman rho = {pair['spearman_rho']} "
                 f"(n = {pair['n_pairs']:,})")
    if sampled:
        ax.text(0.99, 0.01, f"random sample of {n:,} rows shown", transform=ax.transAxes,
                ha="right", fontsize=8.5, color=INK2)
    _save(fig, path)


def plot_group_box(ctx, path, measure, category, title_note=""):
    df = pd.DataFrame({"v": ctx["typed"][measure], "g": ctx["raw_df"][category]}).dropna()
    order = df["g"].value_counts().index[: ctx["cfg"]["group_plot_max_levels"]]
    log = _log_view(df["v"], ctx["cfg"])
    data, labels = [], []
    for g in order[::-1]:
        vals, _ = _transform(df.loc[df["g"] == g, "v"], log)
        data.append(vals)
        labels.append(f"{truncate(g, 40)} (n={len(vals):,})")
    fig, ax = plt.subplots(figsize=(9.5, max(3.5, 0.55 * len(data) + 1.8)))
    ax.boxplot(data, vert=False, widths=0.55, patch_artist=True,
               boxprops=dict(facecolor="#d6e4f7", edgecolor=PRIMARY),
               medianprops=dict(color=ACCENT, lw=2),
               whiskerprops=dict(color=PRIMARY), capprops=dict(color=PRIMARY),
               flierprops=dict(marker="o", markersize=2, markerfacecolor=PRIMARY,
                               markeredgecolor="none", alpha=0.2))
    ax.set_yticks(range(1, len(labels) + 1), labels)
    ax.set_xlabel(_axis_label(measure, log))
    if log:
        _log_ticks(ax, df["v"].max())
    ax.set_ylabel("Category (row count)")
    _title(ax, f"Distribution of '{measure}' by '{category}'{title_note}")
    ax.grid(axis="y", visible=False)
    _save(fig, path)


def plot_time(ctx, path):
    tt = ctx["relationships"]["time_trend"]
    periods = list(tt["rows_per_period"].keys())
    counts = list(tt["rows_per_period"].values())
    has_mean = "mean_per_period" in tt
    fig, axes = plt.subplots(2 if has_mean else 1, 1, figsize=(10, 7 if has_mean else 4.8),
                             sharex=True, squeeze=False)
    ax = axes[0, 0]
    ax.plot(periods, counts, color=PRIMARY, lw=2, marker="o", markersize=4)
    ax.set_ylabel("Number of rows")
    _thousands(ax, "y")
    _title(ax, f"Rows per period of '{tt['period_label']}'")
    if has_mean:
        ax2 = axes[1, 0]
        means = [tt["mean_per_period"].get(p) for p in periods]
        ax2.plot(periods, means, color=PRIMARY, lw=2, marker="o", markersize=4)
        ax2.set_ylabel(f"Mean {truncate(tt['measure'], 25)}")
        _title(ax2, f"Mean '{tt['measure']}' per period"
               + (f" ({tt['mean_note']})" if tt.get("mean_note") else ""))
    last = axes[-1, 0]
    last.set_xlabel(tt["period_label"])
    step = max(1, len(periods) // 18)
    last.set_xticks(range(0, len(periods), step), [periods[i] for i in range(0, len(periods), step)],
                    rotation=45, ha="right")
    _save(fig, path)


# ------------------------------------------------------------------ planner
def plan_and_render(ctx, plots_dir):
    cfg, rel, profiles = ctx["cfg"], ctx["relationships"], ctx["profiles"]
    measures = rel["numeric_measures"]          # for single-variable plots
    plan, skipped = [], []

    # Missing-value bar chart
    if any(p["missing"] > 0 for p in profiles):
        plan.append(("missing", {}, "Missing-value bar chart",
                     "Shows which columns have gaps and how they compare with the high-missing threshold."))
    else:
        skipped.append({"type": "Missing-value bar chart", "reason": "no column has missing values"})

    # Categorical frequency bar charts
    cats = [p for p in profiles if p["role"] in (ROLE_CATEGORICAL, ROLE_BOOLEAN) and 2 <= p["n_unique"]]
    cats.sort(key=lambda p: (p["n_unique"] < 3, p["n_unique"]))
    dominated = {d["column"] for d in ctx["quality"]["dominant_categories"]}
    cats = [p for p in cats if p["column"] not in dominated] + [p for p in cats if p["column"] in dominated]
    cat_plans = [("categorical", {"col": p["column"]}, f"Categorical frequency bar chart ({p['column']})",
                  f"'{p['column']}' is categorical with {p['n_unique']:,} levels; a sorted bar chart of the "
                  f"top {cfg['top_n_categories']} shows the most common values.")
                 for p in cats[: cfg["max_categorical_plots"]]]
    if not cats:
        skipped.append({"type": "Categorical frequency bar chart",
                        "reason": "no categorical or boolean column with at least 2 distinct values"})

    # Histograms + boxplot
    hist_cols = sorted(measures, key=lambda c: -ctx["typed"][c].notna().sum())[: cfg["max_histograms"]]
    hist_plans = [("histogram", {"col": c}, f"Histogram ({c})",
                   f"'{c}' is a numeric measure; a histogram shows its shape, skew and spikes.")
                  for c in hist_cols]
    box_plan = None
    if measures:
        box_cols = hist_cols + [c for c in measures if c not in hist_cols]
        box_cols = box_cols[: cfg["max_boxplot_panels"]]
        box_plan = ("boxplot", {"cols": box_cols}, "Boxplot",
                    "Boxplots display the median, IQR and the points beyond the 1.5×IQR fences.")
    else:
        skipped.append({"type": "Histogram", "reason": "no numeric measure columns"})
        skipped.append({"type": "Boxplot", "reason": "no numeric measure columns"})

    # Scatter + heatmap
    scatter_plan = heat_plan = None
    pairs = rel.get("pairs") or []
    if pairs:
        top = pairs[0]
        scatter_plan = ("scatter", {"pair": top}, "Scatterplot",
                        f"Pairwise view of the strongest correlation ('{top['col_a']}' vs '{top['col_b']}').")
    else:
        skipped.append({"type": "Scatterplot", "reason": "fewer than 2 usable numeric measures"})
    if len(rel["measures_used"]) >= 3:
        heat_plan = ("heatmap", {}, "Correlation heatmap", "Summarises every pairwise Pearson correlation.")
    else:
        skipped.append({"type": "Correlation heatmap",
                        "reason": f"needs at least 3 numeric measures (found {len(rel['measures_used'])}); "
                                  + ("the single pairwise value is shown in the scatterplot"
                                     if len(rel["measures_used"]) == 2 else "no pairwise relationship to show")})

    # Numeric by category
    group_plans = []
    ub = rel.get("unit_breakdown")
    if ub:
        group_plans.append(("group", {"measure": ub["measure"], "category": ub["unit_column"],
                                      "title_note": " (values are in different units)"},
                            "Numeric distribution by category (unit)",
                            f"'{ub['unit_column']}' records units of measure, so '{ub['measure']}' is compared "
                            "within each unit instead of pooled."))
    best = rel.get("best_group_association")
    if best and not (ub and best["measure"] == ub["measure"] and best["category"] == ub["unit_column"]):
        group_plans.append(("group", {"measure": best["measure"], "category": best["category"],
                                      "title_note": ""},
                            "Numeric distribution by category",
                            f"'{best['category']}' explains the most variation in '{best['measure']}' "
                            f"(eta squared = {best['eta_squared']})."))
    if not group_plans:
        skipped.append({"type": "Numeric distribution by category",
                        "reason": "needs a numeric measure and a categorical column with "
                                  f"2-{cfg['group_plot_max_levels']} levels"})

    time_plan = None
    if rel.get("time_trend"):
        time_plan = ("time", {}, "Time-series plot",
                     f"A date-like field ('{rel['time_trend']['period_label']}') allows counts over time.")
    else:
        skipped.append({"type": "Time-series plot", "reason": "no usable date-like column"})

    # Priority order, then cap
    ordered = plan[:1]
    ordered += cat_plans[:1] + hist_plans[:1] + ([box_plan] if box_plan else []) + group_plans[:1]
    ordered += ([time_plan] if time_plan else []) + ([scatter_plan] if scatter_plan else [])
    ordered += ([heat_plan] if heat_plan else []) + cat_plans[1:] + hist_plans[1:] + group_plans[1:]
    for extra in ordered[cfg["max_plots"]:]:
        skipped.append({"type": extra[2], "reason": f"plot limit of {cfg['max_plots']} reached"})
    ordered = ordered[: cfg["max_plots"]]

    renderers = {"missing": plot_missing, "categorical": plot_categorical, "histogram": plot_histogram,
                 "boxplot": lambda c, p, cols: plot_boxplots(c, p, cols), "heatmap": plot_corr_heatmap,
                 "scatter": plot_scatter, "group": plot_group_box, "time": plot_time}
    produced = []
    for kind, kwargs, label, why in ordered:
        fname = f"plot_{len(produced) + 1:02d}.png"
        path = f"{plots_dir}/{fname}"
        try:
            renderers[kind](ctx, path, **kwargs)
            cols = [kwargs[k] for k in ("col", "measure", "category") if k in kwargs]
            cols += kwargs.get("cols", [])
            if "pair" in kwargs:
                cols += [kwargs["pair"]["col_a"], kwargs["pair"]["col_b"]]
            if kind == "time":
                cols.append(rel["time_trend"]["period_label"])
            produced.append({"file": f"plots/{fname}", "type": label, "why": why, "columns": cols})
        except Exception as err:          # one failing chart must not stop the run
            plt.close("all")
            skipped.append({"type": label, "reason": f"rendering failed: {err}"})
    if len(produced) < 5:
        skipped.append({"type": "(overall)", "reason": f"only {len(produced)} meaningful plots could be made "
                        "for this dataset's column types; no filler plots were added"})
    return {"produced": produced, "skipped": skipped}
