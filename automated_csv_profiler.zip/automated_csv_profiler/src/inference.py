"""
inference.py - Infer a technical type and a probable role for every column.

Input : the raw all-text DataFrame from loader.py
Output: (profiles, typed)
    profiles - list of dicts, one per column (name, technical_type, role, counts, notes)
    typed    - dict column -> typed pandas Series (float / datetime / original text)

The rules are applied in a fixed order and every threshold comes from config.py.
The *meaning* of a column is never inferred - only its structure.
"""
import re
import warnings

import numpy as np
import pandas as pd

from utils import name_tokens, pct

ROLE_NUMERIC = "numeric measure"
ROLE_CATEGORICAL = "categorical attribute"
ROLE_BOOLEAN = "boolean field"
ROLE_DATE = "date-like field"
ROLE_ID = "identifier-like field"
ROLE_TEXT = "free-text field"
ROLE_UNKNOWN = "unknown or mixed type"

BOOLEAN_PAIRS = [{"true", "false"}, {"yes", "no"}, {"y", "n"}, {"t", "f"},
                 {"0", "1"}, {"0.0", "1.0"}]

THOUSANDS_RE = re.compile(r"^[+-]?\d{1,3}(,\d{3})+(\.\d+)?$")
CURRENCY_RE = re.compile(r"^[+-]?\$\s?[\d,]+(\.\d+)?$")
PERCENT_RE = re.compile(r"^[+-]?\d+(\.\d+)?\s?%$")
LEADING_ZERO_RE = re.compile(r"^0\d+$")
GEOMETRY_RE = re.compile(r"^\s*(POINT|LINESTRING|POLYGON|MULTIPOINT|MULTIPOLYGON|MULTILINESTRING)\s*Z?\s*\(",
                         re.IGNORECASE)
LATLON_RE = re.compile(r"^\s*\(?\s*[+-]?\d{1,3}\.\d+\s*,\s*[+-]?\d{1,3}\.\d+\s*\)?\s*$")
DATE_HINT_RE = re.compile(r"(?:\d{1,4}[-/.:]\d{1,2})|(?:[A-Za-z]{3,9}\s+\d{1,2})|(?:\d{1,2}\s+[A-Za-z]{3,9})")


# --------------------------------------------------------------------------- helpers
def parse_numeric(text):
    """Convert a text Series to floats, tolerating common number formats.

    Returns (numeric_series, format_notes). Values that cannot be parsed become NaN
    in the *typed copy only*; the raw text is untouched.
    """
    stripped = text.str.strip()
    numeric = pd.to_numeric(stripped, errors="coerce")
    notes = []
    failed = numeric.isna() & stripped.notna()
    if failed.any():
        cand = stripped[failed]
        for regex, label, cleaner in (
            (THOUSANDS_RE, "thousands separators (e.g. '1,234')",
             lambda s: s.str.replace(",", "", regex=False)),
            (CURRENCY_RE, "currency symbols (e.g. '$1,234')",
             lambda s: s.str.replace(r"[$,\s]", "", regex=True)),
            (PERCENT_RE, "percent signs (values kept on the 0-100 scale)",
             lambda s: s.str.replace(r"[%\s]", "", regex=True)),
        ):
            mask = cand.str.match(regex)
            if mask.any():
                numeric.loc[mask[mask].index] = pd.to_numeric(cleaner(cand[mask]), errors="coerce")
                notes.append(f"{int(mask.sum()):,} values written with {label} were parsed as numbers")
                cand = cand[~mask]
    return numeric.astype("float64"), notes


def _is_integer_valued(values):
    v = values.dropna()
    return len(v) > 0 and bool(np.all(np.isclose(v, np.round(v))))


def _try_dates(sample):
    """Share of a text sample that parses as dates, plus the detected format."""
    if sample.empty:
        return 0.0, None
    hinted = sample.str.contains(DATE_HINT_RE).mean()
    if hinted < 0.9:
        return 0.0, None
    fmt = None
    try:
        from pandas.tseries.api import guess_datetime_format
        fmt = guess_datetime_format(str(sample.iloc[0]))
    except Exception:
        fmt = None
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if fmt:
            parsed = pd.to_datetime(sample, format=fmt, errors="coerce")
            if parsed.notna().mean() >= 0.9:
                return float(parsed.notna().mean()), fmt
        parsed = pd.to_datetime(sample, format="mixed", errors="coerce")
    return float(parsed.notna().mean()), None


def _to_datetime(text, fmt):
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if fmt:
            return pd.to_datetime(text, format=fmt, errors="coerce")
        return pd.to_datetime(text, format="mixed", errors="coerce")


# --------------------------------------------------------------------------- main
def infer_column(name, raw, cfg, n_rows):
    """Infer type/role for one column. Returns (profile_dict, typed_series)."""
    tokens = set(name_tokens(name))
    nonnull = raw.dropna()
    n_nonnull = int(nonnull.shape[0])
    n_unique = int(nonnull.nunique())
    prof = {
        "column": name,
        "non_missing": n_nonnull,
        "missing": int(n_rows - n_nonnull),
        "missing_pct": pct(n_rows - n_nonnull, n_rows),
        "n_unique": n_unique,
        "unique_ratio": round(n_unique / n_nonnull, 4) if n_nonnull else 0.0,
        "technical_type": None,
        "role": None,
        "reason": "",
        "notes": [],
    }

    # 1. Entirely empty --------------------------------------------------------------
    if n_nonnull == 0:
        prof.update(technical_type="empty", role=ROLE_UNKNOWN,
                    reason="every value is missing, so no type can be inferred")
        return prof, raw

    rng = np.random.default_rng(cfg["random_seed"])
    sample_n = min(cfg["inference_sample_size"], n_nonnull)
    sample = nonnull.iloc[rng.choice(n_nonnull, size=sample_n, replace=False)] if n_nonnull > sample_n else nonnull
    sample = sample.astype(str)

    # 2. Boolean ------------------------------------------------------------------
    lowered = set(nonnull.str.strip().str.lower().unique()[:3])
    if n_unique <= 2 and len(lowered) == 2 and any(lowered <= pair for pair in BOOLEAN_PAIRS):
        prof.update(technical_type="boolean (stored as text)", role=ROLE_BOOLEAN,
                    reason=f"only two distinct values {sorted(lowered)}, both boolean-like")
        return prof, raw

    # 3. Numeric -----------------------------------------------------------------
    numeric, fmt_notes = parse_numeric(nonnull)
    parse_rate = float(numeric.notna().mean())
    if parse_rate >= cfg["numeric_parse_min"]:
        full_numeric = pd.Series(np.nan, index=raw.index, dtype="float64")
        full_numeric.loc[numeric.index] = numeric
        prof["notes"].extend(fmt_notes)
        n_failed = int(numeric.isna().sum())
        if n_failed:
            examples = nonnull[numeric.isna()].value_counts().head(3).index.tolist()
            prof["notes"].append(f"{n_failed:,} non-missing values could not be parsed as numbers "
                                 f"(e.g. {examples}); treated as missing in numeric statistics")
            prof["unparsed_values"] = n_failed
        is_int = _is_integer_valued(numeric)
        vmin, vmax = numeric.min(), numeric.max()
        leading_zero_share = float(nonnull.str.strip().str.match(LEADING_ZERO_RE).mean())
        prof["technical_type"] = ("integer" if is_int else "float") + (
            " (stored as text with formatting)" if fmt_notes else "")

        if is_int and tokens & set(cfg["year_name_tokens"]) and 1800 <= vmin and vmax <= 2200:
            prof.update(technical_type="year (integer)", role=ROLE_DATE,
                        reason="integer values between 1800 and 2200 in a column whose name contains a year word")
        elif is_int and tokens & set(cfg["month_name_tokens"]) and 1 <= vmin and vmax <= 12:
            prof.update(technical_type="month number (integer 1-12)", role=ROLE_DATE,
                        reason="integers 1-12 in a column whose name contains a month word")
        elif tokens & set(cfg["identifier_name_tokens"]):
            prof.update(role=ROLE_ID, reason="numbers in a column whose name suggests a code or ID "
                                             f"({sorted(tokens & set(cfg['identifier_name_tokens']))}); "
                                             "arithmetic on codes is not meaningful")
        elif leading_zero_share >= 0.05:
            prof.update(role=ROLE_ID, reason=f"{leading_zero_share:.0%} of values have leading zeros, "
                                             "which is typical of codes rather than quantities")
        elif is_int and prof["unique_ratio"] >= cfg["identifier_unique_ratio"] and n_nonnull >= 20:
            prof.update(role=ROLE_ID, reason=f"integer values that are {prof['unique_ratio']:.0%} unique, "
                                             "typical of row identifiers")
        elif n_unique == 1:
            prof.update(role=ROLE_NUMERIC, reason="numeric, but only one distinct value (constant)")
        else:
            prof.update(role=ROLE_NUMERIC, reason=f"{parse_rate:.1%} of non-missing values are numbers")
            if is_int and n_unique <= 10:
                prof["notes"].append(f"only {n_unique} distinct integer values - may be an ordinal "
                                     "scale or a numeric code; its meaning is not documented here")
        return prof, full_numeric

    if parse_rate >= cfg["mixed_parse_min"]:
        examples = nonnull[numeric.isna()].value_counts().head(3).index.tolist()
        prof.update(technical_type="mixed (numbers and text)", role=ROLE_UNKNOWN,
                    reason=f"{parse_rate:.1%} of values are numeric and the rest are text (e.g. {examples})")
        prof["mixed_numeric_share"] = round(parse_rate * 100, 2)
        return prof, raw

    # 4. Text columns ---------------------------------------------------------------
    geo_share = max(sample.str.match(GEOMETRY_RE).mean(), sample.str.match(LATLON_RE).mean())
    if geo_share >= 0.9:
        prof.update(technical_type="coordinate text (geometry)", role=ROLE_UNKNOWN,
                    reason="values look like map coordinates; spatial analysis is outside this tool's scope")
        return prof, raw

    date_rate, fmt = _try_dates(sample)
    if date_rate >= cfg["date_parse_min"]:
        dt = _to_datetime(raw, fmt)
        bad = int(dt.isna().sum() - raw.isna().sum())
        prof.update(technical_type="datetime" + (f" (format {fmt})" if fmt else " (mixed formats)"),
                    role=ROLE_DATE, reason=f"{date_rate:.0%} of sampled values parse as dates")
        if bad > 0:
            prof["notes"].append(f"{bad:,} non-missing values could not be parsed as dates")
            prof["unparsed_values"] = bad
        return prof, dt

    avg_len = float(sample.str.len().mean())
    space_share = float(sample.str.contains(" ").mean())
    prof["avg_length"] = round(avg_len, 1)
    delim_share = float(sample.str.contains(r"[|;]").mean())

    if tokens & set(cfg["identifier_name_tokens"]) and n_unique > cfg["high_cardinality_count"]:
        prof.update(technical_type="string", role=ROLE_ID,
                    reason=f"name suggests an ID/code and it has {n_unique:,} distinct values")
    elif (prof["unique_ratio"] >= cfg["identifier_unique_ratio"] and avg_len < cfg["free_text_min_avg_len"]
          and n_nonnull >= 20):
        prof.update(technical_type="string", role=ROLE_ID,
                    reason=f"short strings that are {prof['unique_ratio']:.0%} unique")
    elif (avg_len >= cfg["free_text_min_avg_len"] and space_share >= 0.5
          and prof["unique_ratio"] >= cfg["free_text_min_unique_ratio"]):
        prof.update(technical_type="string", role=ROLE_TEXT,
                    reason=f"long (avg {avg_len:.0f} chars), mostly unique text with spaces")
    elif n_unique == 1:
        prof.update(technical_type="string", role=ROLE_CATEGORICAL,
                    reason="text with only one distinct value (constant)")
    else:
        prof.update(technical_type="string", role=ROLE_CATEGORICAL,
                    reason=f"text with {n_unique:,} distinct values repeated across rows")
    if delim_share >= cfg["multi_value_min_share"]:
        prof["notes"].append(f"{delim_share:.0%} of sampled values contain '|' or ';' - "
                             "the field may hold several values per row")
        prof["multi_valued"] = True
    return prof, raw


def infer_types(raw_df, cfg):
    profiles, typed = [], {}
    n_rows = len(raw_df)
    for col in raw_df.columns:
        prof, series = infer_column(col, raw_df[col], cfg, n_rows)
        profiles.append(prof)
        typed[col] = series
    return profiles, typed
