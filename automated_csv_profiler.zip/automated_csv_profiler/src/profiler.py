"""
profiler.py - Entry point of the Automated CSV Profiler.

    CSV file -> Python analysis -> verified summary -> LLM explanation -> generated report

Python usage:
    from profiler import generate_profile
    generate_profile("data/my.csv", output_dir="output", use_llm=True)

Command line:
    python src/profiler.py --csv data/my.csv --out output --name dataset_a
    python src/profiler.py --csv data/my.csv --no-llm

Only the CSV path (and optional documented options) changes between datasets.
"""
import argparse
import os
import re
import shutil
import sys
import time
from datetime import datetime

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config import build_config                       # noqa: E402
from facts import build_facts                         # noqa: E402
from inference import infer_types                     # noqa: E402
from llm import build_prompt, call_ollama, check_available  # noqa: E402
from loader import load_csv                           # noqa: E402
from quality import run_quality_checks                # noqa: E402
from relationships import analyze_relationships       # noqa: E402
from report import ROLE_ORDER, build_report           # noqa: E402
from stats import compute_statistics                  # noqa: E402
from utils import write_json                          # noqa: E402
from verify import fill_to_requirements, verify_insights  # noqa: E402
from viz import plan_and_render                       # noqa: E402


def _slug(text):
    return re.sub(r"[^A-Za-z0-9]+", "_", text).strip("_").lower() or "dataset"


def _log(msg):
    print(f"[profiler] {msg}", flush=True)


def required_categories(facts):
    cats = {f["category"] for f in facts}
    req = ["data_quality"]
    if "distribution" in cats:
        req.append("distribution")
    if "categorical" in cats:
        req.append("categorical")
    if "relationship" in cats:
        req.append("relationship")
    req += ["limitation", "follow_up_question"]
    return req


def generate_profile(csv_path, output_dir="output", use_llm=True, dataset_name=None, model=None,
                     config_overrides=None):
    """Profile one CSV and write report.md, column_profile.csv, analysis_summary.json,
    plots/, llm_prompt.txt and llm_response.txt into output_dir/<dataset_name>/.
    Returns a dict with the output paths."""
    t0 = time.time()
    overrides = dict(config_overrides or {})
    if model:
        overrides["llm_model"] = model
    cfg = build_config(overrides)

    name = _slug(dataset_name or os.path.splitext(os.path.basename(csv_path))[0])
    out_dir = os.path.join(output_dir, name)
    plots_dir = os.path.join(out_dir, "plots")
    if os.path.isdir(plots_dir):
        shutil.rmtree(plots_dir)          # remove stale plots from an earlier run
    os.makedirs(plots_dir, exist_ok=True)

    _log(f"1/7 loading {csv_path}")
    raw_df, info = load_csv(csv_path)
    _log(f"    {info['n_rows']:,} rows x {info['n_columns']} columns")

    _log("2/7 inferring column types and roles")
    profiles, typed = infer_types(raw_df, cfg)

    _log("3/7 running data-quality checks")
    quality = run_quality_checks(raw_df, profiles, typed, cfg)

    _log("4/7 computing descriptive statistics and relationships")
    stats = compute_statistics(raw_df, profiles, typed, quality, cfg)
    relationships = analyze_relationships(raw_df, profiles, typed, quality, stats, cfg)

    role_counts = {r: sum(1 for p in profiles if p["role"] == r) for r in ROLE_ORDER}
    overview = {**info, "role_counts": {k: v for k, v in role_counts.items() if v},
                "generated_at": datetime.now().strftime("%Y-%m-%d %H:%M:%S")}

    _log("5/7 selecting and drawing visualizations")
    ctx = {"cfg": cfg, "raw_df": raw_df, "typed": typed, "profiles": profiles, "quality": quality,
           "stats": stats, "relationships": relationships}
    viz = plan_and_render(ctx, plots_dir)
    _log(f"    {len(viz['produced'])} plots saved, {len(viz['skipped'])} plot types skipped")

    summary = {"overview": overview, "column_profiles": profiles, "quality": quality, "statistics": stats,
               "relationships": relationships, "visualizations": viz,
               "config_used": {k: v for k, v in cfg.items() if not isinstance(v, list)}}
    facts = build_facts(summary)
    summary["facts"] = facts
    required = required_categories(facts)

    # ---------------------------------------------------------------- LLM stage
    _log("6/7 LLM explanation stage")
    system_prompt, user_prompt = build_prompt(facts, overview, required, cfg)
    prompt_path = os.path.join(out_dir, "llm_prompt.txt")
    response_path = os.path.join(out_dir, "llm_response.txt")
    with open(prompt_path, "w", encoding="utf-8") as fh:
        fh.write(f"# model: {cfg['llm_model']}  temperature: {cfg['llm_temperature']}  "
                 f"sent: {'yes' if use_llm else 'no (LLM disabled with --no-llm)'}\n\n")
        fh.write("=== SYSTEM ===\n" + system_prompt + "\n\n=== USER ===\n" + user_prompt + "\n")

    llm = {"status": "skipped", "model": cfg["llm_model"] if use_llm else None, "reason": "", "verification": None}
    raw_response = None
    if not use_llm:
        llm["reason"] = "the LLM component was disabled for this run (--no-llm / use_llm=False)."
    else:
        ok, reason = check_available(cfg)
        if not ok:
            llm["reason"] = f"the model was unavailable: {reason}"
        else:
            try:
                _log(f"    calling Ollama model {cfg['llm_model']} ...")
                raw_response = call_ollama(system_prompt, user_prompt, cfg)
                llm["status"] = "used"
            except Exception as err:
                llm["reason"] = f"the model call failed: {type(err).__name__}: {err}"
    with open(response_path, "w", encoding="utf-8") as fh:
        if raw_response is not None:
            fh.write(raw_response)
        else:
            fh.write(f"AI-generated narrative insights were skipped because {llm['reason']}\n")

    if llm["status"] == "used":
        insights, llm_summary, vlog = verify_insights(raw_response, facts, summary, required, cfg)
        llm["verification"] = vlog
        llm["llm_summary"] = llm_summary
        _log(f"    verification: {vlog['n_accepted']} accepted, {vlog['n_rejected']} rejected, "
             f"template fill for {vlog['template_fill_categories'] or 'none'}")
    else:
        _log(f"    skipped: {llm['reason']}")
        insights, _ = fill_to_requirements([], facts, summary, required, cfg)
    summary["llm"] = llm
    summary["insights"] = insights
    summary["runtime_seconds"] = round(time.time() - t0, 1)

    # ---------------------------------------------------------------- outputs
    _log("7/7 writing report and summary files")
    col_rows = []
    for p in profiles:
        col_rows.append({"column": p["column"], "technical_type": p["technical_type"], "role": p["role"],
                         "non_missing": p["non_missing"], "missing": p["missing"], "missing_pct": p["missing_pct"],
                         "n_unique": p["n_unique"], "unique_ratio": p["unique_ratio"],
                         "role_reason": p["reason"], "notes": " | ".join(p["notes"])})
    pd.DataFrame(col_rows).to_csv(os.path.join(out_dir, "column_profile.csv"), index=False)
    write_json(os.path.join(out_dir, "analysis_summary.json"), summary)
    with open(os.path.join(out_dir, "report.md"), "w", encoding="utf-8") as fh:
        fh.write(build_report(summary))
    _log(f"done in {summary['runtime_seconds']} s -> {out_dir}")
    return {"output_dir": out_dir, "report": os.path.join(out_dir, "report.md"),
            "summary": os.path.join(out_dir, "analysis_summary.json"), "llm_status": llm["status"]}


def main(argv=None):
    ap = argparse.ArgumentParser(description="Automated CSV profiler with verified LLM insights.")
    ap.add_argument("--csv", required=True, help="path to the CSV file to analyse")
    ap.add_argument("--out", default="output", help="parent output folder (default: output)")
    ap.add_argument("--name", default=None, help="output sub-folder name (default: CSV file name)")
    ap.add_argument("--no-llm", action="store_true", help="skip the LLM stage (deterministic report only)")
    ap.add_argument("--model", default=None, help="Ollama model name (default in config.py)")
    ap.add_argument("--missing-threshold", type=float, default=None, help="high-missing threshold in %% (default 30)")
    ap.add_argument("--max-plots", type=int, default=None, help="maximum number of plots (default 10)")
    ap.add_argument("--top-n", type=int, default=None, help="categories listed per column (default 10)")
    args = ap.parse_args(argv)
    overrides = {"high_missing_pct": args.missing_threshold, "max_plots": args.max_plots,
                 "top_n_categories": args.top_n}
    try:
        generate_profile(args.csv, args.out, use_llm=not args.no_llm, dataset_name=args.name,
                         model=args.model, config_overrides=overrides)
    except (FileNotFoundError, ValueError) as err:
        print(f"[profiler] ERROR: {err}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
