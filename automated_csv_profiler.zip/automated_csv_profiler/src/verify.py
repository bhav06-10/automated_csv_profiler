"""
verify.py - Check every LLM insight against the Python-computed facts.

An insight is ACCEPTED only if:
  * it cites at least one existing fact ID,
  * every number in its text matches a number in the cited facts (or, with a
    warning, another fact) after allowing for normal rounding,
  * every `backticked` name is a real column or appears in a fact,
  * it contains no causal language (causes, leads to, drives, due to, ...).
Rejected insights are logged with the reason and left out of the report body.
If fewer than the minimum remain, or a required category is missing, deterministic
template insights (built directly from the facts) fill the gap and are labelled.
"""
import json
import re

from facts import template_insights

NUM_RE = re.compile(r"(?<![\w.])[-+]?\d[\d,]*(?:\.\d+)?(?:\s*(million|billion|thousand))?")
CAUSAL_RE = re.compile(r"\b(cause[sd]?|causing|lead(s)? to|led to|result(s|ed)? in|drive[sn]?|driven by|"
                       r"due to|because of|impact(s|ed)? on|effect of)\b", re.IGNORECASE)
BACKTICK_RE = re.compile(r"`([^`]+)`")
QUOTED_RE = re.compile(r"'[^']*'|\"[^\"]*\"")
MULT = {"thousand": 1e3, "million": 1e6, "billion": 1e9}
VALID_CATEGORIES = {"data_quality", "distribution", "categorical", "relationship", "limitation",
                    "follow_up_question"}


def extract_numbers(text):
    """Return list of (value, decimals, raw) found in text."""
    out = []
    for m in NUM_RE.finditer(text):
        raw = m.group(0)
        word = m.group(1)
        num = raw.replace(",", "")
        if word:
            num = num[: num.lower().rfind(word.lower())].strip()
        try:
            val = float(num)
        except ValueError:
            continue
        dec = len(num.split(".")[1]) if "." in num else 0
        if word:
            val *= MULT[word.lower()]
        out.append((val, dec, raw.strip(), MULT.get((word or "").lower(), 1)))
    return out


def _fact_numbers(fact):
    nums = [float(v) for v in fact["values"].values() if isinstance(v, (int, float)) and v is not None]
    nums += [n[0] for n in extract_numbers(fact["statement"])]
    return nums


def _matches(val, dec, mult, candidates):
    tol = 0.5 * (10 ** -dec) * mult + 1e-9
    for c in candidates:
        if abs(val - c) <= tol or (c != 0 and abs(val - c) / abs(c) <= 0.001):
            return True
    return False


def _strip_names(text, columns):
    """Remove backticked names and known column names so digits inside names are not checked."""
    text = BACKTICK_RE.sub(" ", text)
    for col in sorted(columns, key=len, reverse=True):
        text = text.replace(col, " ")
    return text


def _norm_category(cat):
    c = re.sub(r"[\s\-/]+", "_", str(cat).strip().lower())
    aliases = {"quality": "data_quality", "dataquality": "data_quality", "follow_up": "follow_up_question",
               "followup": "follow_up_question", "question": "follow_up_question",
               "followup_question": "follow_up_question", "relationships": "relationship",
               "limitations": "limitation", "bias": "limitation", "limitation_bias": "limitation",
               "categorical_finding": "categorical", "distribution_finding": "distribution"}
    return aliases.get(c, c)


def _norm_fact_id(fid):
    m = re.fullmatch(r"\s*F?0*(\d+)\s*", str(fid), re.IGNORECASE)
    return f"F{int(m.group(1)):02d}" if m else str(fid).strip()


def parse_llm_json(raw):
    try:
        return json.loads(raw)
    except Exception:
        m = re.search(r"\{.*\}", raw or "", re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                return None
    return None


def verify_text(text, fact_ids, facts_by_id, all_facts, columns):
    """Return (ok, reasons, checks) for one piece of LLM text."""
    reasons, checks = [], []
    unknown = [i for i in fact_ids if i not in facts_by_id]
    if unknown:
        reasons.append(f"cites unknown fact IDs {unknown}")
    cited = [facts_by_id[i] for i in fact_ids if i in facts_by_id]
    cited_nums = [n for f in cited for n in _fact_numbers(f)]
    all_nums = [n for f in all_facts for n in _fact_numbers(f)]
    for val, dec, raw, mult in extract_numbers(_strip_names(text, columns)):
        if _matches(val, dec, mult, cited_nums):
            checks.append({"number": raw, "status": "matches cited fact"})
        elif _matches(val, dec, mult, all_nums):
            checks.append({"number": raw, "status": "matches a fact that was not cited (accepted with warning)"})
        else:
            checks.append({"number": raw, "status": "NOT FOUND in any verified fact"})
            reasons.append(f"number {raw} is not supported by any verified fact")
    fact_text = " ".join(f["statement"] for f in all_facts)
    for name in BACKTICK_RE.findall(text):
        if name not in columns and name not in fact_text:
            reasons.append(f"refers to `{name}`, which is not a column or a verified value")
    unquoted = QUOTED_RE.sub(" ", BACKTICK_RE.sub(" ", text))
    causal = CAUSAL_RE.search(unquoted)
    if causal:
        reasons.append(f"uses causal language ('{causal.group(0)}')")
    return (not reasons), reasons, checks


def verify_insights(raw_response, facts, summary, required, cfg):
    columns = [p["column"] for p in summary["column_profiles"]]
    facts_by_id = {f["id"]: f for f in facts}
    parsed = parse_llm_json(raw_response)
    log = {"parsed_json": parsed is not None, "insights": [], "summary_check": None}
    accepted = []
    llm_summary = None
    if parsed:
        s = parsed.get("summary") if isinstance(parsed, dict) else None
        if isinstance(s, str) and s.strip():
            ok, reasons, checks = verify_text(s, list(facts_by_id), facts_by_id, facts, columns)
            log["summary_check"] = {"text": s, "accepted": ok, "reasons": reasons, "number_checks": checks}
            llm_summary = s if ok else None
        items = parsed if isinstance(parsed, list) else (parsed.get("insights", []) or [])
        for item in items:
            if not isinstance(item, dict):
                continue
            text = str(item.get("text") or item.get("insight") or "").strip()
            cat = _norm_category(item.get("category", ""))
            raw_ids = item.get("fact_ids") or item.get("facts") or []
            if isinstance(raw_ids, str):
                raw_ids = re.split(r"[,\s]+", raw_ids)
            ids = [_norm_fact_id(i) for i in raw_ids if str(i).strip()]
            reasons = []
            if cat not in VALID_CATEGORIES:
                reasons.append(f"unknown category '{cat}'")
            if not ids and cat != "follow_up_question":
                reasons.append("cites no fact IDs")
            ok, r2, checks = verify_text(text, ids, facts_by_id, facts, columns)
            reasons += r2
            entry = {"category": cat, "text": text, "fact_ids": ids, "accepted": not reasons,
                     "reasons": reasons, "number_checks": checks}
            log["insights"].append(entry)
            if not reasons:
                accepted.append({"category": cat, "text": text, "fact_ids": ids, "source": "llm"})
    accepted = accepted[: cfg["max_insights"]]
    log["n_llm_insights"] = len(log["insights"])
    log["n_accepted"] = len(accepted)
    log["n_rejected"] = len(log["insights"]) - sum(1 for e in log["insights"] if e["accepted"])
    final, filled = fill_to_requirements(accepted, facts, summary, required, cfg)
    log["template_fill_categories"] = filled
    return final, llm_summary, log


def fill_to_requirements(insights, facts, summary, required, cfg):
    """Add template insights for missing required categories and up to the minimum count."""
    have = {i["category"] for i in insights}
    missing = [c for c in required if c not in have]
    extra = template_insights(facts, summary, missing)
    out = list(insights)
    # replace surplus LLM insights if adding templates would exceed the maximum
    while len(out) + len(extra) > cfg["max_insights"] and out:
        cats = [i["category"] for i in out]
        dup = next((k for k in range(len(out) - 1, -1, -1) if cats.count(cats[k]) > 1), None)
        if dup is None:
            break
        out.pop(dup)
    out += extra
    if len(out) < cfg["min_insights"]:
        pool = ["data_quality", "distribution", "categorical", "relationship", "limitation"]
        more = template_insights(facts, summary, pool * 2)
        used = {i for o in out for i in o["fact_ids"]}
        for m in more:
            if len(out) >= cfg["min_insights"]:
                break
            if not set(m["fact_ids"]) & used:
                out.append(m)
                used |= set(m["fact_ids"])
    return out[: cfg["max_insights"]], [e["category"] for e in extra]
