"""
llm.py - Ask a local Ollama model to *explain* the verified facts.

The model never sees the raw CSV. It receives the numbered facts produced by
facts.py and must return JSON insights that cite fact IDs. Uses only the Python
standard library (urllib), so no API key and no extra dependency is needed.
If Ollama is not running or the model is missing, the caller falls back gracefully.
"""
import json
import os
import urllib.error
import urllib.request

SYSTEM_PROMPT = """You are a careful data analyst writing the insight section of an automated data-profile report.
You are given VERIFIED FACTS that were computed by Python. You must follow these rules:
1. Use ONLY the facts provided. Do not calculate, estimate, round differently or invent any number.
   Every number you write must appear exactly in one of the facts you cite.
2. Cite the fact IDs (e.g. "F03") that support each insight in the "fact_ids" list.
3. Refer to columns by their exact names in backticks, e.g. `column name`.
4. Do NOT guess the meaning, definition or units of any column, code or abbreviation that the facts do not explain.
5. Do NOT claim that one variable causes, drives, leads to or is due to another. Correlation is not causation.
6. Do not present speculation as fact. Use cautious words such as "may" or "suggests" for interpretations.
7. Reply with JSON only, no text outside the JSON."""

USER_TEMPLATE = """Dataset: {filename} ({n_rows} rows, {n_columns} columns)

VERIFIED FACTS (JSON lines: id, category, columns, statement):
{facts}

TASK: Write between {min_i} and {max_i} concise, evidence-based insights (1-2 sentences each).
Together they MUST include at least one insight of each of these categories: {required}.
- data_quality: a data-quality finding
- distribution: a finding about the distribution of a numeric column
- categorical: a finding about a categorical column
- relationship: a relationship between variables (association only)
- limitation: a limitation or potential bias of this data or analysis
- follow_up_question: one question worth investigating further (phrase it as a question)
Each quantitative insight must name the relevant column and quote a count, percentage or statistic from the facts.
Also write a 2-3 sentence "summary" of the dataset using only the facts.

Return JSON exactly in this shape:
{{"summary": "...", "insights": [{{"category": "data_quality", "text": "...", "fact_ids": ["F02"]}}]}}"""


def build_prompt(facts, overview, required, cfg):
    lines = "\n".join(json.dumps({"id": f["id"], "category": f["category"], "columns": f["columns"],
                                  "statement": f["statement"]}, ensure_ascii=False) for f in facts)
    user = USER_TEMPLATE.format(filename=overview["filename"], n_rows=f"{overview['n_rows']:,}",
                                n_columns=overview["n_columns"], facts=lines, min_i=cfg["min_insights"],
                                max_i=cfg["max_insights"], required=", ".join(required))
    return SYSTEM_PROMPT, user


def _host(cfg):
    return os.environ.get("OLLAMA_HOST", cfg["llm_host"]).rstrip("/")


def check_available(cfg):
    """Return (ok, reason). Checks the server is up and the model is pulled."""
    url = f"{_host(cfg)}/api/tags"
    try:
        with urllib.request.urlopen(url, timeout=5) as resp:
            tags = json.loads(resp.read().decode("utf-8"))
    except Exception as err:
        return False, (f"Ollama server not reachable at {_host(cfg)} ({type(err).__name__}: {err}). "
                       f"Start it with `ollama serve` or run with --no-llm.")
    names = {m.get("name", "") for m in tags.get("models", [])}
    want = cfg["llm_model"]
    if want in names or f"{want}:latest" in names or want.replace(":latest", "") in names:
        return True, "ok"
    return False, (f"Model '{want}' is not installed in Ollama (installed: {sorted(names) or 'none'}). "
                   f"Run `ollama pull {want}`.")


def call_ollama(system_prompt, user_prompt, cfg):
    """Send one chat request; returns the raw text of the model's reply."""
    payload = {
        "model": cfg["llm_model"],
        "messages": [{"role": "system", "content": system_prompt},
                     {"role": "user", "content": user_prompt}],
        "stream": False,
        "format": "json",
        "options": {"temperature": cfg["llm_temperature"], "seed": cfg["random_seed"]},
    }
    req = urllib.request.Request(f"{_host(cfg)}/api/chat", data=json.dumps(payload).encode("utf-8"),
                                 headers={"Content-Type": "application/json"}, method="POST")
    with urllib.request.urlopen(req, timeout=cfg["llm_timeout_s"]) as resp:
        body = json.loads(resp.read().decode("utf-8"))
    return body.get("message", {}).get("content", "")
