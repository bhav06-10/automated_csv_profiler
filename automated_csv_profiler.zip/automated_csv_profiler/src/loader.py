"""
loader.py - Read any reasonably well-formed CSV *without changing it*.

Design choice: every column is read as text (dtype=str). Type inference is then
done by our own code (inference.py) instead of pandas' silent guessing. This
means values such as "12,700,000" or "00501" are seen exactly as written, and
the original DataFrame is never modified - typed copies are made separately.
"""
import csv
import os

import pandas as pd

ENCODINGS = ["utf-8", "utf-8-sig", "cp1252", "latin-1"]


def _sniff_delimiter(path, encoding):
    """Guess the delimiter from the first 64 KB; default to a comma."""
    try:
        with open(path, "r", encoding=encoding, newline="") as fh:
            sample = fh.read(65536)
        return csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
    except Exception:
        return ","


def load_csv(path):
    """Return (raw_df, load_info). raw_df holds strings; blanks become NaN.

    pandas' default NA tokens ('', 'NA', 'N/A', 'null', 'NaN', ...) are treated as
    missing. Other suspicious tokens ('-', '?', 'unknown') are *not* converted -
    quality.py reports them as possible disguised missing values instead.
    """
    if not os.path.isfile(path):
        raise FileNotFoundError(f"CSV not found: {path}")
    if os.path.getsize(path) == 0:
        raise ValueError(f"CSV file is empty: {path}")

    last_error = None
    for enc in ENCODINGS:
        try:
            sep = _sniff_delimiter(path, enc)
            if sep == "|":           # '|' often appears *inside* values; trust ',' unless it fails
                sep = ","
            df = pd.read_csv(path, dtype=str, encoding=enc, sep=sep,
                             skipinitialspace=False, on_bad_lines="warn")
            info = {
                "path": os.path.abspath(path),
                "filename": os.path.basename(path),
                "file_size_mb": round(os.path.getsize(path) / 1_048_576, 2),
                "encoding": enc,
                "delimiter": sep,
                "n_rows": int(df.shape[0]),
                "n_columns": int(df.shape[1]),
            }
            # Strip surrounding whitespace in headers only (values are left untouched).
            df.columns = [str(c).strip() for c in df.columns]
            unnamed = [c for c in df.columns if c.startswith("Unnamed:")]
            info["unnamed_columns"] = unnamed   # e.g. an exported index column
            return df, info
        except UnicodeDecodeError as err:
            last_error = err
            continue
    raise ValueError(f"Could not decode {path} with encodings {ENCODINGS}: {last_error}")
