"""
stats.py - Descriptive statistics chosen by column role.

numeric measure      -> count, missing, min, max, mean, median, mode, std, Q1, Q3, IQR,
                        1.5*IQR outlier count, skewness, zeros, negatives
categorical/boolean  -> distinct count, top-N frequencies and percentages
date-like            -> range and counts per period
identifier-like      -> distinct count and repeated IDs only (no arithmetic)
free text            -> length summary only
"""
import numpy as np
import pandas as pd

from inference import (ROLE_BOOLEAN, ROLE_CATEGORICAL, ROLE_DATE, ROLE_ID, ROLE_NUMERIC,
                       ROLE_TEXT)
from utils import pct, rnd


def numeric_stats(s_all, cfg, sentinel_codes=()):
    n_total = len(s_all)
    s = s_all.dropna()
    out = {"valid_count": int(len(s)), "missing_count": int(n_total - len(s)),
           "missing_pct": pct(n_total - len(s), n_total)}
    if s.empty:
        out["note"] = "no valid numeric values"
        return out
    q1, med, q3 = s.quantile([0.25, 0.5, 0.75]).tolist()
    iqr = q3 - q1
    k = cfg["iqr_multiplier"]
    lo, hi = q1 - k * iqr, q3 + k * iqr
    n_low, n_high = int((s < lo).sum()), int((s > hi).sum())
    out.update({
        "min": rnd(s.min()), "max": rnd(s.max()), "mean": rnd(s.mean()), "median": rnd(med),
        "std": rnd(s.std(ddof=1)) if len(s) > 1 else None,
        "q1": rnd(q1), "q3": rnd(q3), "iqr": rnd(iqr),
        "lower_fence": rnd(lo), "upper_fence": rnd(hi),
        "outlier_count": n_low + n_high, "outlier_pct": pct(n_low + n_high, len(s)),
        "outliers_below": n_low, "outliers_above": n_high,
        "skewness": rnd(s.skew()) if len(s) > 2 else None,
        "zero_count": int((s == 0).sum()), "zero_pct": pct(int((s == 0).sum()), len(s)),
        "negative_count": int((s < 0).sum()),
        "n_unique": int(s.nunique()),
    })
    if iqr == 0:
        out["outlier_note"] = ("IQR is 0 (at least half the values are identical), so every value "
                               "different from that value is flagged by the 1.5*IQR rule")
    # Mode is only 'meaningful' when values repeat (discrete / low-uniqueness data).
    vc = s.value_counts()
    integer_like = bool(np.all(np.isclose(s, np.round(s))))
    if vc.iloc[0] > 1 and (integer_like or s.nunique() / len(s) <= 0.5):
        ties = int((vc == vc.iloc[0]).sum())
        out["mode"] = rnd(vc.index[0])
        out["mode_count"] = int(vc.iloc[0])
        out["mode_pct"] = pct(vc.iloc[0], len(s))
        if ties > 1:
            out["mode_note"] = f"{ties} values tie for most frequent; the smallest is shown"
            out["mode"] = rnd(vc[vc == vc.iloc[0]].index.min())
    else:
        out["mode"] = None
        out["mode_note"] = "not meaningful: values are mostly unique (continuous)"
    # Supplementary view without suspected sentinel codes (data itself is unchanged).
    codes = [c for c in sentinel_codes]
    if codes:
        s2 = s[~s.isin(codes)]
        out["excluding_sentinels"] = {"codes": codes, "valid_count": int(len(s2)),
                                      "mean": rnd(s2.mean()), "median": rnd(s2.median()),
                                      "min": rnd(s2.min()), "max": rnd(s2.max())}
    return out


def categorical_stats(raw, cfg):
    n_total = len(raw)
    s = raw.dropna()
    vc = s.value_counts()
    top_n = cfg["top_n_categories"]
    out = {"valid_count": int(len(s)), "missing_count": int(n_total - len(s)),
           "missing_pct": pct(n_total - len(s), n_total), "n_unique": int(len(vc))}
    if vc.empty:
        return out
    out.update({"top_value": str(vc.index[0]), "top_count": int(vc.iloc[0]),
                "top_pct": pct(vc.iloc[0], len(s)),
                "top_categories": [{"value": str(v), "count": int(c), "pct_of_non_missing": pct(c, len(s)),
                                    "pct_of_all_rows": pct(c, n_total)} for v, c in vc.head(top_n).items()],
                "shown": int(min(top_n, len(vc)))})
    if len(vc) > top_n:
        other = int(vc.iloc[top_n:].sum())
        out["other_categories"] = {"n_categories": int(len(vc) - top_n), "count": other,
                                   "pct_of_non_missing": pct(other, len(s))}
    return out


def date_stats(typed, prof, cfg):
    s = typed.dropna()
    out = {"valid_count": int(len(s)), "missing_pct": prof["missing_pct"]}
    if s.empty:
        return out
    if pd.api.types.is_datetime64_any_dtype(s):
        out.update({"min": s.min().isoformat(), "max": s.max().isoformat(),
                    "span_days": int((s.max() - s.min()).days)})
        by_year = s.dt.year.value_counts().sort_index()
        out["counts_by_year"] = {str(int(k)): int(v) for k, v in by_year.items()}
    else:  # numeric calendar component (year or month)
        out.update({"min": int(s.min()), "max": int(s.max())})
        vc = s.astype(int).value_counts().sort_index()
        out["counts_by_value"] = {str(k): int(v) for k, v in vc.items()}
        peak = vc.idxmax()
        out["most_common"] = {"value": int(peak), "count": int(vc.max()), "pct": pct(vc.max(), len(s))}
    return out


def identifier_stats(raw, prof):
    s = raw.dropna()
    dup = int(s.duplicated().sum())
    return {"valid_count": int(len(s)), "n_unique": prof["n_unique"],
            "unique_ratio": prof["unique_ratio"], "repeated_values": dup,
            "note": "identifier-like: excluded from arithmetic, correlation and distance calculations"}


def text_stats(raw):
    s = raw.dropna().astype(str)
    lens = s.str.len()
    return {"valid_count": int(len(s)), "n_unique": int(s.nunique()),
            "avg_length": rnd(lens.mean()), "min_length": int(lens.min()) if len(s) else None,
            "max_length": int(lens.max()) if len(s) else None}


def compute_statistics(raw_df, profiles, typed, quality, cfg):
    sentinels = {}
    for d in quality["possible_sentinel_codes"]:
        sentinels.setdefault(d["column"], []).append(d["value"])
    result = {"numeric": {}, "categorical": {}, "boolean": {}, "date": {}, "identifier": {},
              "free_text": {}, "skipped": []}
    for p in profiles:
        col, role = p["column"], p["role"]
        if role == ROLE_NUMERIC:
            result["numeric"][col] = numeric_stats(typed[col], cfg, sentinels.get(col, ()))
        elif role == ROLE_CATEGORICAL:
            result["categorical"][col] = categorical_stats(raw_df[col], cfg)
        elif role == ROLE_BOOLEAN:
            result["boolean"][col] = categorical_stats(raw_df[col], cfg)
        elif role == ROLE_DATE:
            result["date"][col] = date_stats(typed[col], p, cfg)
        elif role == ROLE_ID:
            result["identifier"][col] = identifier_stats(raw_df[col], p)
        elif role == ROLE_TEXT:
            result["free_text"][col] = text_stats(raw_df[col])
    if not result["numeric"]:
        result["skipped"].append("Numeric statistics and outlier analysis were skipped: no column was "
                                 "inferred as a numeric measure (numeric codes/IDs are excluded on purpose).")
    if not result["categorical"] and not result["boolean"]:
        result["skipped"].append("Categorical frequency analysis was skipped: no categorical or boolean "
                                 "columns were found.")
    if not result["date"]:
        result["skipped"].append("Date/time summaries were skipped: no date-like column was found.")
    return result
