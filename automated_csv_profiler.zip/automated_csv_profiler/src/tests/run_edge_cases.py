"""
run_edge_cases.py - Generalisation test: build awkward CSVs and make sure the
profiler finishes on every one of them without code changes.

    python src/tests/run_edge_cases.py

Creates src/tests/edge_cases/*.csv, runs generate_profile(..., use_llm=False) on
each, and checks that all six required output items exist. Also checks the
graceful-failure path by pointing the LLM at a port where nothing is listening.
"""
import os
import sys
import tempfile

import numpy as np
import pandas as pd

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.dirname(HERE))
from profiler import generate_profile  # noqa: E402

CASE_DIR = os.path.join(HERE, "edge_cases")
rng = np.random.default_rng(0)


def make_cases():
    os.makedirs(CASE_DIR, exist_ok=True)
    n = 400
    cases = {
        # only text columns - numeric stats, correlation, histograms must be skipped with reasons
        "all_text.csv": pd.DataFrame({"city": rng.choice(["Boulder", "Denver", "Aurora"], n),
                                      "status": rng.choice(["open", "closed", "pending"], n),
                                      "comment": [f"free text comment number {i} about the service" for i in range(n)]}),
        # only numbers - categorical plots must be skipped; heatmap should appear
        "numeric_only.csv": pd.DataFrame({"a": rng.normal(10, 2, n), "b": rng.exponential(5, n),
                                          "c": rng.integers(0, 100, n), "d": rng.normal(0, 1, n)}),
        # one column
        "single_column.csv": pd.DataFrame({"score": rng.normal(70, 10, 50)}),
        # a column that is entirely empty + booleans + dates + duplicates + mixed type + sentinel
        "messy.csv": pd.DataFrame({
            "id": range(n), "empty": [None] * n,
            "flag": rng.choice(["Yes", "No"], n),
            "when": pd.date_range("2023-01-01", periods=n, freq="D").strftime("%Y-%m-%d"),
            "amount": np.where(rng.random(n) < 0.05, -999, rng.gamma(2, 50, n).round(2)),
            "mixed": [str(i) if i % 3 else "n/a-code" for i in range(n)],
            "email": [f"user{i}@example.com" for i in range(n)],
            "grade": rng.choice(["A", "a", "B", "b ", "C"], n),
        }),
        # tiny file
        "tiny.csv": pd.DataFrame({"x": [1, 2, 3], "y": ["a", "b", "a"]}),
    }
    cases["messy.csv"] = pd.concat([cases["messy.csv"], cases["messy.csv"].head(5)])  # 5 duplicate rows
    paths = []
    for name, df in cases.items():
        p = os.path.join(CASE_DIR, name)
        df.to_csv(p, index=False)
        paths.append(p)
    # a Windows-1252 encoded file (not valid UTF-8)
    p = os.path.join(CASE_DIR, "latin1_encoded.csv")
    with open(p, "w", encoding="cp1252") as fh:
        fh.write("name,price\nCafé,3.50\nCrème brûlée,6.25\nNaïve tea,2.00\n")
    paths.append(p)
    # semicolon-delimited file
    p = os.path.join(CASE_DIR, "semicolon.csv")
    pd.DataFrame({"k": ["x", "y", "z"] * 10, "v": range(30)}).to_csv(p, index=False, sep=";")
    paths.append(p)
    return paths


REQUIRED = ["report.md", "column_profile.csv", "analysis_summary.json", "plots",
            "llm_prompt.txt", "llm_response.txt"]


def main():
    out = tempfile.mkdtemp(prefix="edge_out_")
    failures = 0
    for path in make_cases():
        name = os.path.basename(path)
        try:
            res = generate_profile(path, out, use_llm=False)
            missing = [r for r in REQUIRED if not os.path.exists(os.path.join(res["output_dir"], r))]
            status = "OK" if not missing else f"MISSING {missing}"
            failures += bool(missing)
        except Exception as err:          # a crash on any supported CSV is a failure
            status = f"CRASH {type(err).__name__}: {err}"
            failures += 1
        print(f"=== {name:22s} {status}")
    # graceful LLM failure: nothing listens on this port
    os.environ["OLLAMA_HOST"] = "http://localhost:9"
    res = generate_profile(os.path.join(CASE_DIR, "tiny.csv"), out, use_llm=True, dataset_name="llm_down")
    report = open(res["report"], encoding="utf-8").read()
    ok = res["llm_status"] == "skipped" and "AI-generated narrative insights were skipped" in report
    print(f"=== LLM unavailable       {'OK' if ok else 'FAILED'}")
    failures += not ok
    print(f"\n{failures} failure(s). Outputs in {out}")
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
