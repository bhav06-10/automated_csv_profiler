"""
mock_ollama.py - A tiny fake Ollama server for TESTING the LLM + verifier path
without a real model. It imitates /api/tags and /api/chat.

Its reply deliberately mixes good insights (copied from the verified facts) with
two bad ones - an invented statistic and a causal claim - so you can see the
verifier reject them.

    python src/tests/mock_ollama.py            # listens on http://localhost:11434
    python src/profiler.py --csv data/x.csv --model mock-model

Never used for the submitted reports; those must come from a real model.
"""
import json
import re
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer

PORT = int(sys.argv[1]) if len(sys.argv) > 1 else 11434


def fake_reply(user_prompt):
    facts = [json.loads(line) for line in user_prompt.splitlines() if line.startswith('{"id"')]
    by_cat = {}
    for f in facts:
        by_cat.setdefault(f["category"], []).append(f)
    insights = []
    for cat in ("data_quality", "distribution", "categorical", "relationship", "limitation"):
        if by_cat.get(cat):
            f = by_cat[cat][-1] if cat == "limitation" else by_cat[cat][0]
            insights.append({"category": cat, "text": f["statement"], "fact_ids": [f["id"]]})
    col = (by_cat.get("distribution") or facts)[0]["columns"][:1] or ["the data"]
    insights.append({"category": "follow_up_question",
                     "text": f"What explains the shape of the distribution of `{col[0]}`?", "fact_ids": []})
    # --- two deliberately bad insights --------------------------------------
    insights.append({"category": "distribution", "fact_ids": [facts[1]["id"]],
                     "text": f"The average of `{col[0]}` grew by 37.5% every year."})         # invented number
    if by_cat.get("relationship"):
        r = by_cat["relationship"][0]
        insights.append({"category": "relationship", "fact_ids": [r["id"]],
                         "text": f"Higher `{r['columns'][0]}` causes changes in `{r['columns'][-1]}`."})  # causal
    first = re.sub(r"`", "", facts[0]["statement"])
    return json.dumps({"summary": first, "insights": insights})


class Handler(BaseHTTPRequestHandler):
    def _send(self, obj):
        body = json.dumps(obj).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if self.path == "/api/tags":
            self._send({"models": [{"name": "mock-model:latest"}]})

    def do_POST(self):
        data = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        user = next(m["content"] for m in data["messages"] if m["role"] == "user")
        self._send({"message": {"role": "assistant", "content": fake_reply(user)}, "done": True})

    def log_message(self, *args):
        pass


if __name__ == "__main__":
    print(f"mock Ollama listening on http://localhost:{PORT}")
    HTTPServer(("127.0.0.1", PORT), Handler).serve_forever()
