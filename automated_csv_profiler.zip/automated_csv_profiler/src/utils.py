"""utils.py - small helpers shared by several modules."""
import json
import math
import re

import numpy as np
import pandas as pd


def name_tokens(column_name):
    """Split a column name into lowercase word tokens.

    'DOL Vehicle ID' -> ['dol', 'vehicle', 'id'];  'number_of_accounts' ->
    ['number', 'of', 'accounts'];  'zipCode' -> ['zip', 'code'].
    Whole-token matching avoids false hits such as 'usage' containing 'age'.
    """
    s = re.sub(r"([a-z])([A-Z])", r"\1 \2", str(column_name))
    return [t for t in re.split(r"[^A-Za-z0-9]+", s.lower()) if t]


def pct(part, whole, digits=2):
    """Percentage rounded to `digits`; 0.0 when whole is 0."""
    if not whole:
        return 0.0
    return round(100.0 * part / whole, digits)


def rnd(x, digits=4):
    """Round floats for reporting; pass through None/NaN as None."""
    if x is None:
        return None
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return x
    if math.isnan(xf) or math.isinf(xf):
        return None
    if xf.is_integer() and abs(xf) < 1e15:
        return int(xf)
    # keep ~4 significant decimals for small numbers, fewer for big ones
    if abs(xf) >= 1000:
        return round(xf, 2)
    return round(xf, digits)


def fmt_num(x):
    """Human-readable number for the Markdown report (thousands separators)."""
    if x is None:
        return "n/a"
    if isinstance(x, (int, np.integer)):
        return f"{int(x):,}"
    try:
        xf = float(x)
    except (TypeError, ValueError):
        return str(x)
    if math.isnan(xf):
        return "n/a"
    if xf.is_integer() and abs(xf) < 1e15:
        return f"{int(xf):,}"
    if abs(xf) >= 1:
        return f"{xf:,.2f}"
    return f"{xf:.4g}"          # small values: up to 4 significant digits, no trailing zeros


def truncate(label, max_chars):
    label = str(label)
    return label if len(label) <= max_chars else label[: max_chars - 1] + "…"


def to_jsonable(obj):
    """Recursively convert numpy / pandas objects into plain JSON types."""
    if isinstance(obj, dict):
        return {str(k): to_jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple, set)):
        return [to_jsonable(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating, float)):
        f = float(obj)
        return None if (math.isnan(f) or math.isinf(f)) else f
    if isinstance(obj, (np.bool_,)):
        return bool(obj)
    if isinstance(obj, (pd.Timestamp,)):
        return obj.isoformat()
    if obj is pd.NaT:
        return None
    return obj


def write_json(path, obj):
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(to_jsonable(obj), fh, indent=2, ensure_ascii=False)


def md_escape(text):
    """Escape characters that would break a Markdown table cell."""
    return str(text).replace("|", "\\|").replace("\n", " ")
