"""
relationships.py - Relationships between variables (never interpreted as causation).

1. Correlation matrix (Pearson + Spearman) over numeric *measures* only.
   Identifier-like, date-like, constant and boolean columns are excluded.
2. Numeric-by-category association (eta squared) for low-cardinality categories.
3. Trend over time when a date-like column exists.
Each part records a 'skipped' reason when the data cannot support it.
"""
import numpy as np
import pandas as pd

from inference import ROLE_BOOLEAN, ROLE_CATEGORICAL, ROLE_DATE, ROLE_NUMERIC
from utils import name_tokens, pct, rnd

CAUSATION_NOTE = ("Correlation and group differences describe association only; they do not "
                  "show that one variable causes another.")


def strength(r):
    a = abs(r)
    return "negligible" if a < 0.1 else "weak" if a < 0.3 else "moderate" if a < 0.5 else "strong"


def _eta_squared(values, groups):
    df = pd.DataFrame({"v": values, "g": groups}).dropna()
    if df["g"].nunique() < 2 or len(df) < 3:
        return None
    grand = df["v"].mean()
    ss_total = float(((df["v"] - grand) ** 2).sum())
    if ss_total == 0:
        return None
    means = df.groupby("g")["v"].agg(["mean", "count"])
    ss_between = float((means["count"] * (means["mean"] - grand) ** 2).sum())
    return ss_between / ss_total


def _group_table(values, groups, max_levels):
    df = pd.DataFrame({"v": values, "g": groups}).dropna()
    agg = df.groupby("g")["v"].agg(count="count", mean="mean", median="median",
                                   zero_share=lambda x: (x == 0).mean() * 100)
    agg = agg.sort_values("count", ascending=False).head(max_levels)
    return [{"group": str(g), "count": int(r["count"]), "mean": rnd(r["mean"]),
             "median": rnd(r["median"]), "zero_pct": round(float(r["zero_share"]), 2)}
            for g, r in agg.iterrows()]


def analyze_relationships(raw_df, profiles, typed, quality, stats, cfg):
    out = {"causation_note": CAUSATION_NOTE, "skipped": []}
    rng_seed = cfg["random_seed"]
    n_rows = len(raw_df)
    measures = [p["column"] for p in profiles if p["role"] == ROLE_NUMERIC and p["n_unique"] > 1
                and p["non_missing"] >= cfg["min_pairs_for_correlation"]]
    out["measures_used"] = measures
    # all non-constant numeric measures (used for histograms/boxplots even on tiny files)
    out["numeric_measures"] = [p["column"] for p in profiles if p["role"] == ROLE_NUMERIC and p["n_unique"] > 1]
    excluded = [p["column"] for p in profiles if p["role"] != ROLE_NUMERIC and
                p["technical_type"] and ("integer" in p["technical_type"] or "float" in p["technical_type"]
                                         or "year" in p["technical_type"] or "month" in p["technical_type"])]
    out["numeric_columns_excluded"] = excluded
    sentinel = {}
    for d in quality["possible_sentinel_codes"]:
        sentinel.setdefault(d["column"], []).append(d["value"])

    # ---------------------------------------------------------------- 1. correlation
    if len(measures) >= 2:
        num = pd.DataFrame({c: typed[c] for c in measures})
        pear = num.corr(method="pearson", min_periods=cfg["min_pairs_for_correlation"])
        spear = num.corr(method="spearman", min_periods=cfg["min_pairs_for_correlation"])
        out["pearson_matrix"] = {c: {d: rnd(pear.loc[c, d]) for d in measures} for c in measures}
        out["spearman_matrix"] = {c: {d: rnd(spear.loc[c, d]) for d in measures} for c in measures}
        pairs = []
        for i, a in enumerate(measures):
            for b in measures[i + 1:]:
                r = pear.loc[a, b]
                if pd.isna(r):
                    continue
                n_pairs = int(num[[a, b]].dropna().shape[0])
                pair = {"col_a": a, "col_b": b, "pearson_r": rnd(r), "spearman_rho": rnd(spear.loc[a, b]),
                        "n_pairs": n_pairs, "strength": strength(r)}
                codes_a, codes_b = sentinel.get(a, []), sentinel.get(b, [])
                if codes_a or codes_b:
                    sub = num[[a, b]].dropna()
                    sub = sub[~sub[a].isin(codes_a) & ~sub[b].isin(codes_b)]
                    if len(sub) >= cfg["min_pairs_for_correlation"]:
                        pair["pearson_r_excluding_sentinels"] = rnd(sub[a].corr(sub[b]))
                pairs.append(pair)
        pairs.sort(key=lambda d: -abs(d["pearson_r"]))
        out["pairs"] = pairs
        pos = [p for p in pairs if p["pearson_r"] > 0]
        neg = [p for p in pairs if p["pearson_r"] < 0]
        out["strongest_positive"] = max(pos, key=lambda d: d["pearson_r"]) if pos else None
        out["strongest_negative"] = min(neg, key=lambda d: d["pearson_r"]) if neg else None
        if not neg:
            out["no_negative_note"] = "No pair of numeric measures has a negative Pearson correlation."
    else:
        out["skipped"].append(
            f"Correlation analysis was skipped: it needs at least 2 non-constant numeric measures, "
            f"but {len(measures)} were found ({', '.join(measures) or 'none'}). "
            + (f"Numeric-looking columns {excluded} were excluded because they are codes, IDs or "
               "calendar fields." if excluded else ""))

    # ---------------------------------------------------- 2. numeric by category
    cat_candidates = []
    for p in profiles:
        if p["role"] in (ROLE_CATEGORICAL, ROLE_BOOLEAN) and 2 <= p["n_unique"] <= cfg["group_plot_max_levels"]:
            dom = [d for d in quality["dominant_categories"] if d["column"] == p["column"]]
            if not dom:
                cat_candidates.append(p["column"])
    unit_cols = [u["column"] for u in quality["unit_columns"] if u["n_unique"] <= 20]
    if measures and (cat_candidates or unit_cols):
        idx = raw_df.index
        if n_rows > cfg["relationship_sample_size"]:
            idx = raw_df.sample(n=cfg["relationship_sample_size"], random_state=rng_seed).index
        scores = []
        for m in measures:
            for c in cat_candidates:
                e = _eta_squared(typed[m].loc[idx], raw_df[c].loc[idx])
                if e is not None:
                    scores.append({"measure": m, "category": c, "eta_squared": rnd(e)})
        scores.sort(key=lambda d: -d["eta_squared"])
        out["group_associations"] = scores[:10]
        if scores:
            best = dict(scores[0])
            best["sample_rows"] = int(len(idx))
            best["groups"] = _group_table(typed[best["measure"]], raw_df[best["category"]],
                                          cfg["group_plot_max_levels"])
            out["best_group_association"] = best
        if unit_cols:
            # The unit most likely applies to the measure that differs most across units.
            unit_scores = [d for d in scores if d["category"] == unit_cols[0]]
            main = (max(unit_scores, key=lambda d: d["eta_squared"])["measure"] if unit_scores
                    else max(measures, key=lambda c: typed[c].notna().sum()))
            out["unit_breakdown"] = {"measure": main, "unit_column": unit_cols[0],
                                     "groups": _group_table(typed[main], raw_df[unit_cols[0]], 20),
                                     "note": "Summaries of this measure across all rows combine different "
                                             "units; per-unit groups are shown for comparison."}
    else:
        out["skipped"].append("Numeric-by-category comparison was skipped: it needs a numeric measure and a "
                              f"categorical column with 2-{cfg['group_plot_max_levels']} levels that is not "
                              "dominated by one value.")

    # ---------------------------------------------------------------- 3. time trend
    date_cols = [p for p in profiles if p["role"] == ROLE_DATE]
    period = None
    if date_cols:
        year_col = next((p["column"] for p in date_cols if p["technical_type"].startswith("year")), None)
        month_col = next((p["column"] for p in date_cols if p["technical_type"].startswith("month")), None)
        dt_col = next((p["column"] for p in date_cols if p["technical_type"].startswith("datetime")), None)
        if dt_col:
            s = typed[dt_col]
            span = (s.max() - s.min()).days if s.notna().any() else 0
            freq = "Y" if span > 3 * 365 else "M"
            period = s.dt.to_period(freq).astype(str).where(s.notna())
            label = f"{dt_col} ({'year' if freq == 'Y' else 'month'})"
        elif year_col and month_col:
            y, mth = typed[year_col], typed[month_col]
            ok = y.notna() & mth.notna()
            period = pd.Series(pd.NA, index=raw_df.index, dtype="object")
            period[ok] = (y[ok].astype(int).astype(str) + "-" + mth[ok].astype(int).astype(str).str.zfill(2))
            label = f"{year_col} + {month_col} (year-month)"
        elif year_col:
            period = typed[year_col].dropna().astype(int).astype(str).reindex(raw_df.index)
            label = year_col
        elif month_col:
            period = typed[month_col].dropna().astype(int).astype(str).str.zfill(2).reindex(raw_df.index)
            label = f"{month_col} (calendar month, all years pooled)"
    if period is not None and period.notna().sum() > 0:
        counts = period.value_counts().sort_index()
        trend = {"period_label": label, "n_periods": int(len(counts)),
                 "first_period": str(counts.index[0]), "last_period": str(counts.index[-1]),
                 "rows_per_period": {str(k): int(v) for k, v in counts.items()},
                 "peak_period": str(counts.idxmax()), "peak_count": int(counts.max())}
        if measures:
            main = max(measures, key=lambda c: typed[c].notna().sum())
            if quality["unit_columns"]:
                trend["mean_skipped"] = ("Means of numeric measures per period were not computed because a unit "
                                         f"column ('{quality['unit_columns'][0]['column']}') indicates values "
                                         "recorded in different units.")
            else:
                vals = typed[main]
                if sentinel.get(main):
                    vals = vals.where(~vals.isin(sentinel[main]))
                    trend["mean_note"] = f"excluding suspected code(s) {sentinel[main]}"
                means = vals.groupby(period).mean()
                trend["measure"] = main
                trend["mean_per_period"] = {str(k): rnd(v) for k, v in means.sort_index().items()}
        out["time_trend"] = trend
    else:
        out["skipped"].append("Time-trend analysis was skipped: no usable date-like column was found.")
    return out
