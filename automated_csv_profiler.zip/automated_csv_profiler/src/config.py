"""
config.py - Every threshold and heuristic used by the profiler, in one place.

Nothing in this file refers to a specific dataset. Changing a value here changes
behaviour for *every* CSV, which is how the "no hard-coding" rule is satisfied.
Each value has a short justification so it can be cited in the README/report.
"""

DEFAULTS = {
    # ------------------------------------------------------------------ quality
    # A column missing >= 30% of its values is flagged. 30% is the threshold the
    # assignment suggests; beyond it, any summary of the column describes less
    # than ~2/3 of the rows, so conclusions become fragile.
    "high_missing_pct": 30.0,

    # Categorical columns with more distinct values than this are "high cardinality".
    "high_cardinality_count": 50,
    # ...or whose distinct-value ratio (unique / non-missing) is above this.
    "high_cardinality_ratio": 0.50,

    # A category holding >= this share of non-missing rows is "dominant" (imbalance).
    "dominant_category_pct": 95.0,

    # A numeric column with >= this share of exact zeros is "zero-inflated".
    "zero_inflation_pct": 30.0,

    # Codes often used to mean "missing / withheld". Flagged (never replaced)
    # when they are the column min or max AND make up >= sentinel_min_pct of rows.
    "sentinel_values": [-999999, -99999, -9999, -999, -99, 999, 9999, 99999, 999999],
    "sentinel_min_pct": 0.1,

    # Text tokens that look like disguised missing values (exact, case-insensitive).
    "disguised_missing_tokens": ["-", "--", "?", "unknown", "none", "n/a", "na",
                                 "null", "missing", "not available", ".", "blank"],

    # ------------------------------------------------------------ type inference
    # Share of non-missing values that must parse as numbers for a column to be numeric.
    "numeric_parse_min": 0.95,
    # Between mixed_parse_min and numeric_parse_min parsed -> "mixed / inconsistent".
    "mixed_parse_min": 0.05,
    # Share of sampled values that must parse as dates for a text column to be date-like.
    "date_parse_min": 0.90,
    # Integer columns whose unique ratio is >= this are identifier-like.
    "identifier_unique_ratio": 0.95,
    # Text columns: average length and share-with-spaces that suggest free text.
    "free_text_min_avg_len": 30,
    "free_text_min_unique_ratio": 0.50,
    # Share of values containing a list delimiter ("|" or ";") -> multi-valued field.
    "multi_value_min_share": 0.20,
    # Rows sampled for expensive per-value checks (date parsing, regex patterns).
    "inference_sample_size": 2000,

    # Name tokens (whole words of the column name) that suggest a code/identifier.
    "identifier_name_tokens": ["id", "ids", "code", "codes", "zip", "zipcode", "postal",
                               "fips", "geoid", "tract", "district", "key", "vin",
                               "uuid", "guid", "ssn", "isbn", "sku"],
    # Name tokens that mark a numeric column as a calendar component.
    "year_name_tokens": ["year", "yr", "fy"],
    "month_name_tokens": ["month", "mon", "mo"],
    # Name tokens that mark a categorical column as a unit-of-measure column.
    "unit_name_tokens": ["unit", "units", "uom"],

    # --------------------------------------------------------------- sensitivity
    # Name tokens that suggest personal / location / sensitive content.
    "sensitive_name_tokens": ["email", "phone", "mobile", "ssn", "social", "address",
                              "street", "dob", "birth", "birthdate", "zip", "zipcode",
                              "postal", "lat", "latitude", "lon", "lng", "longitude",
                              "location", "coordinates", "geoid", "tract", "license",
                              "passport", "vin", "ip", "gender", "sex", "race",
                              "ethnicity", "salary", "income", "patient", "medical",
                              "diagnosis", "age", "religion"],
    # "name" is only sensitive when paired with a person-like qualifier (or alone):
    # 'customer_name' is flagged, 'county_name' is not.
    "person_name_qualifiers": ["first", "last", "full", "middle", "given", "family",
                               "sur", "person", "customer", "patient", "owner",
                               "contact", "user", "employee", "student", "driver",
                               "applicant", "client"],
    # A value pattern is reported when it matches at least this many sampled values.
    "sensitive_min_matches": 5,

    # ------------------------------------------------------------ statistics
    "top_n_categories": 10,    # at most this many categories are printed per column
    "iqr_multiplier": 1.5,     # outlier fences: Q1 - 1.5*IQR, Q3 + 1.5*IQR

    # --------------------------------------------------------- relationships
    "min_pairs_for_correlation": 10,
    "group_plot_max_levels": 10,   # categorical levels allowed in numeric-by-category
    "relationship_sample_size": 50000,
    "random_seed": 42,

    # --------------------------------------------------------- visualisation
    "max_plots": 10,
    "max_categorical_plots": 2,
    "max_histograms": 2,
    "max_boxplot_panels": 4,
    "scatter_sample_size": 5000,
    "skew_log_threshold": 2.0,     # |skew| above this -> log axis (if values allow)
    "label_max_chars": 36,         # long category labels are truncated in plots

    # --------------------------------------------------------------------- LLM
    "llm_model": "llama3.1:8b",
    "llm_host": "http://localhost:11434",
    "llm_timeout_s": 300,
    "llm_temperature": 0.0,
    "min_insights": 5,
    "max_insights": 8,
}


def build_config(overrides=None):
    """Return a copy of DEFAULTS with any non-None overrides applied."""
    cfg = dict(DEFAULTS)
    for key, value in (overrides or {}).items():
        if value is not None:
            if key not in cfg:
                raise KeyError(f"Unknown configuration option: {key}")
            cfg[key] = value
    return cfg
