"""
facts.py - Turn the computed results into a numbered list of *verified facts*.

Every fact is a sentence written by Python from numbers Python computed. The LLM
receives ONLY these facts and must cite their IDs; verify.py then checks that every
number the LLM writes appears in a cited fact. This is the evidence layer.

Also provides deterministic 'template' insights used when the LLM is disabled,
unavailable, or produces too few verifiable insights.
"""
from utils import fmt_num as f


class FactBook:
    def __init__(self):
        self.facts = []

    def add(self, category, columns, statement, **values):
        fid = f"F{len(self.facts) + 1:02d}"
        self.facts.append({"id": fid, "category": category, "columns": list(columns),
                           "statement": statement, "values": values})
        return fid

    def by_category(self, cat):
        return [x for x in self.facts if x["category"] == cat]


def build_facts(summary):
    fb = FactBook()
    ov, q, st, rel = summary["overview"], summary["quality"], summary["statistics"], summary["relationships"]
    n = ov["n_rows"]

    # ---------------------------------------------------------------- overview
    roles = ", ".join(f"{v} {k}" for k, v in ov["role_counts"].items())
    fb.add("overview", [], f"The file '{ov['filename']}' has {f(n)} rows and {ov['n_columns']} columns "
                           f"({roles}).", n_rows=n, n_columns=ov["n_columns"], **{
                               f"n_{k.split()[0]}": v for k, v in ov["role_counts"].items()})

    # ------------------------------------------------------------ data quality
    d = q["duplicate_rows"]
    fb.add("data_quality", [], f"There are {f(d['count'])} fully duplicated rows ({d['pct']}% of {f(n)} rows).",
           count=d["count"], pct=d["pct"], n_rows=n)
    for m in q["high_missing_columns"]:
        fb.add("data_quality", [m["column"]],
               f"`{m['column']}` is missing for {f(m['missing'])} of {f(n)} rows ({m['missing_pct']}%), "
               f"above the {q['thresholds']['high_missing_pct']:g}% high-missing threshold.",
               missing=m["missing"], n_rows=n, missing_pct=m["missing_pct"],
               threshold=q["thresholds"]["high_missing_pct"])
    for m in [x for x in q["missing_by_column"] if x not in q["high_missing_columns"]][:3]:
        fb.add("data_quality", [m["column"]],
               f"`{m['column']}` is missing for {f(m['missing'])} of {f(n)} rows ({m['missing_pct']}%).",
               missing=m["missing"], n_rows=n, missing_pct=m["missing_pct"])
    if not q["missing_by_column"]:
        fb.add("data_quality", [], "No column contains missing values (blank or standard NA markers).")
    if q["missing_by_column"]:
        fb.add("data_quality", [], f"{f(q['rows_with_any_missing'])} rows ({q['rows_with_any_missing_pct']}%) "
                                   f"have at least one missing value.",
               rows=q["rows_with_any_missing"], pct=q["rows_with_any_missing_pct"])
    for c in q["constant_columns"]:
        fb.add("data_quality", [c["column"]],
               f"`{c['column']}` has only one distinct non-missing value ('{c['value']}'), so it carries no "
               f"information for comparison" + (f"; it is also missing in {c['missing_pct']}% of rows."
                                                if c["missing_pct"] else "."), missing_pct=c["missing_pct"])
    for item in q["mixed_or_inconsistent"]:
        for g in item["case_variants"][:2]:
            parts = " vs ".join(f"'{k}' ({f(v)} rows)" for k, v in g["variants"].items())
            fb.add("data_quality", [item["column"]],
                   f"`{item['column']}` contains values that differ only by letter case or spacing: {parts}.",
                   **{f"count_{i + 1}": v for i, v in enumerate(g["variants"].values())})
    for s in q["possible_sentinel_codes"]:
        fb.add("data_quality", [s["column"]],
               f"`{s['column']}` contains the value {s['value']} in {f(s['count'])} rows "
               f"({s['pct_of_non_missing']}% of non-missing values); this looks like a code for missing or "
               f"withheld data rather than a real measurement, but its meaning is not documented in the file.",
               code=s["value"], count=s["count"], pct=s["pct_of_non_missing"])
    for z in q["zero_inflated_columns"]:
        fb.add("data_quality", [z["column"]],
               f"`{z['column']}` is exactly 0 in {f(z['zero_count'])} rows ({z['zero_pct']}% of non-missing "
               f"values); whether 0 is a real value or means 'not recorded' cannot be determined from the data.",
               zero_count=z["zero_count"], zero_pct=z["zero_pct"])
    for u in q["unit_columns"]:
        vals = ", ".join(f"'{k}' ({f(v)})" for k, v in u["values"].items())
        fb.add("data_quality", [u["column"]],
               f"`{u['column']}` records units of measure with {u['n_unique']} distinct spellings: {vals}. "
               f"Numeric values in the same rows are therefore in different units.",
               n_unique=u["n_unique"], **{f"unit_{i + 1}": v for i, v in enumerate(u["values"].values())})
    for dmn in q["dominant_categories"]:
        fb.add("data_quality", [dmn["column"]],
               f"`{dmn['column']}` is dominated by one value: '{dmn['value']}' in {f(dmn['count'])} rows "
               f"({dmn['pct_of_non_missing']}% of non-missing).", count=dmn["count"], pct=dmn["pct_of_non_missing"])
    if q["identifier_like_columns"]:
        cols = [c["column"] for c in q["identifier_like_columns"]]
        fb.add("data_quality", cols, f"{len(cols)} column(s) are identifier- or code-like and were excluded from "
                                     f"arithmetic and correlation: " + ", ".join(f"`{c}`" for c in cols) + ".",
               n_columns=len(cols))
    if q["potentially_sensitive"]:
        cols = [c["column"] for c in q["potentially_sensitive"]]
        fb.add("data_quality", cols, f"{len(cols)} column(s) may contain sensitive or location information "
                                     f"(name/pattern heuristic): " + ", ".join(f"`{c}`" for c in cols) + ".",
               n_columns=len(cols))
    for item in q["mixed_or_inconsistent"]:
        for issue in item["issues"]:
            if "were parsed as numbers" in issue or "do not match" in issue or "delimiters" in issue:
                fb.add("data_quality", [item["column"]], f"`{item['column']}`: {issue}.")
    for dm in q["disguised_missing_tokens"]:
        fb.add("data_quality", [dm["column"]],
               f"`{dm['column']}` has {f(dm['count'])} values ({dm['pct']}% of rows) that look like disguised "
               f"missing markers: {dm['tokens']}.", count=dm["count"], pct=dm["pct"])

    # ------------------------------------------------------------ distribution
    for col, s in st["numeric"].items():
        if "mean" not in s:
            continue
        fb.add("distribution", [col],
               f"`{col}` ranges from {f(s['min'])} to {f(s['max'])}; mean {f(s['mean'])}, median {f(s['median'])}, "
               f"standard deviation {f(s['std'])}, Q1 {f(s['q1'])}, Q3 {f(s['q3'])} (valid n = {f(s['valid_count'])}).",
               min=s["min"], max=s["max"], mean=s["mean"], median=s["median"], std=s["std"], q1=s["q1"],
               q3=s["q3"], valid_count=s["valid_count"])
        skew_word = ("strongly right-skewed" if (s["skewness"] or 0) > 1 else
                     "strongly left-skewed" if (s["skewness"] or 0) < -1 else "roughly symmetric or mildly skewed")
        fb.add("distribution", [col],
               f"`{col}` has skewness {s['skewness']} ({skew_word}); the 1.5×IQR rule flags {f(s['outlier_count'])} "
               f"values ({s['outlier_pct']}%) as potential outliers outside [{f(s['lower_fence'])}, "
               f"{f(s['upper_fence'])}]. They were flagged, not removed.",
               skewness=s["skewness"], outlier_count=s["outlier_count"], outlier_pct=s["outlier_pct"],
               lower_fence=s["lower_fence"], upper_fence=s["upper_fence"])
        if s.get("mode") is not None:
            fb.add("distribution", [col], f"The most frequent value of `{col}` is {f(s['mode'])}, occurring in "
                                          f"{f(s['mode_count'])} rows ({s['mode_pct']}%).",
                   mode=s["mode"], mode_count=s["mode_count"], mode_pct=s["mode_pct"])
        if s.get("excluding_sentinels"):
            e = s["excluding_sentinels"]
            fb.add("distribution", [col], f"Excluding the suspected code(s) {e['codes']}, `{col}` has mean "
                                          f"{f(e['mean'])} and median {f(e['median'])} (n = {f(e['valid_count'])}).",
                   mean=e["mean"], median=e["median"], valid_count=e["valid_count"])

    # ------------------------------------------------------------- categorical
    cat_items = list(st["categorical"].items()) + list(st["boolean"].items())
    for col, s in cat_items[:8]:
        if "top_value" not in s:
            continue
        extra = ""
        if len(s["top_categories"]) > 1:
            s2 = s["top_categories"][1]
            extra = f" The second most common is '{s2['value']}' ({f(s2['count'])} rows, {s2['pct_of_non_missing']}%)."
        fb.add("categorical", [col], f"`{col}` has {f(s['n_unique'])} distinct values; the most common is "
                                     f"'{s['top_value']}' with {f(s['top_count'])} rows ({s['top_pct']}% of "
                                     f"non-missing).{extra}",
               n_unique=s["n_unique"], top_count=s["top_count"], top_pct=s["top_pct"],
               **({"second_count": s["top_categories"][1]["count"],
                   "second_pct": s["top_categories"][1]["pct_of_non_missing"]} if len(s["top_categories"]) > 1 else {}))

    # ------------------------------------------------------------ relationships
    for key, word in (("strongest_positive", "positive"), ("strongest_negative", "negative")):
        p = rel.get(key)
        if p:
            fb.add("relationship", [p["col_a"], p["col_b"]],
                   f"The strongest {word} correlation between numeric measures is `{p['col_a']}` vs "
                   f"`{p['col_b']}`: Pearson r = {p['pearson_r']} ({p['strength']}), Spearman rho = "
                   f"{p['spearman_rho']}, over {f(p['n_pairs'])} rows. This is an association, not causation.",
                   pearson_r=p["pearson_r"], spearman_rho=p["spearman_rho"], n_pairs=p["n_pairs"])
    if rel.get("pairs") and not rel.get("strongest_negative"):
        fb.add("relationship", rel["measures_used"], "No pair of numeric measures is negatively correlated.")
    b = rel.get("best_group_association")
    if b:
        groups = "; ".join(f"'{g['group']}': median {f(g['median'])}, mean {f(g['mean'])}, n = {f(g['count'])}"
                           for g in b["groups"][:4])
        vals = {"eta_squared": b["eta_squared"]}
        for i, g in enumerate(b["groups"][:4]):
            vals.update({f"g{i + 1}_median": g["median"], f"g{i + 1}_mean": g["mean"], f"g{i + 1}_count": g["count"],
                         f"g{i + 1}_zero_pct": g["zero_pct"]})
        fb.add("relationship", [b["measure"], b["category"]],
               f"`{b['category']}` is the categorical column most associated with `{b['measure']}` "
               f"(eta squared = {b['eta_squared']}, estimated on a {f(b['sample_rows'])}-row sample): {groups}. "
               f"Zero share by group: " + "; ".join(f"'{g['group']}' {g['zero_pct']}%" for g in b["groups"][:4]) + ".",
               sample_rows=b["sample_rows"], **vals)
    ub = rel.get("unit_breakdown")
    if ub:
        groups = "; ".join(f"'{g['group']}': median {f(g['median'])}, n = {f(g['count'])}" for g in ub["groups"][:5])
        vals = {}
        for i, g in enumerate(ub["groups"][:5]):
            vals.update({f"g{i + 1}_median": g["median"], f"g{i + 1}_count": g["count"], f"g{i + 1}_mean": g["mean"]})
        fb.add("relationship", [ub["measure"], ub["unit_column"]],
               f"`{ub['measure']}` differs by `{ub['unit_column']}`: {groups}.", **vals)
    tt = rel.get("time_trend")
    if tt:
        fb.add("temporal", [tt["period_label"]],
               f"Rows span {tt['n_periods']} periods of {tt['period_label']} from {tt['first_period']} to "
               f"{tt['last_period']}; the busiest period is {tt['peak_period']} with {f(tt['peak_count'])} rows.",
               n_periods=tt["n_periods"], peak_count=tt["peak_count"])
        if tt.get("mean_per_period"):
            mp = tt["mean_per_period"]
            first, last = list(mp.items())[0], list(mp.items())[-1]
            fb.add("temporal", [tt["measure"], tt["period_label"]],
                   f"Mean `{tt['measure']}`" + (f" ({tt['mean_note']})" if tt.get("mean_note") else "")
                   + f" is {f(first[1])} in {first[0]} and {f(last[1])} in {last[0]}.",
                   first_mean=first[1], last_mean=last[1])
    for col, s in st["date"].items():
        if "min" in s and "most_common" in s:
            mc = s["most_common"]
            fb.add("temporal", [col], f"`{col}` runs from {s['min']} to {s['max']}; the most common value is "
                                      f"{mc['value']} ({f(mc['count'])} rows, {mc['pct']}%).",
                   min=s["min"], max=s["max"], count=mc["count"], pct=mc["pct"])

    # -------------------------------------------------------------- limitations
    fb.add("limitation", [], "The CSV does not document what each column means or its units; this analysis "
                             "describes structure only and does not interpret undocumented codes or abbreviations.")
    fb.add("limitation", [], "Relationships reported here are associations; they do not establish causation.")
    if q["missing_by_column"]:
        fb.add("limitation", [], "The data do not reveal why values are missing, so missing values may not be "
                                 "random and could bias summaries of the affected columns.")
    if q["possible_sentinel_codes"]:
        fb.add("limitation", [s["column"] for s in q["possible_sentinel_codes"]],
               "Suspected missing-value codes are still included in the headline statistics because the "
               "program never alters data; means and ranges of those columns are distorted by them.")
    if q["unit_columns"]:
        fb.add("limitation", [u["column"] for u in q["unit_columns"]],
               "Overall statistics of numeric columns pool values recorded in different units, so they should "
               "not be interpreted as a single physical quantity.")
    if q["zero_inflated_columns"]:
        fb.add("limitation", [z["column"] for z in q["zero_inflated_columns"]],
               "Large shares of exact zeros may represent unrecorded values; if so, means and medians are "
               "biased downward.")
    fb.add("limitation", [], "The sensitive-data check is a name/pattern heuristic; the absence of a warning does "
                             "not mean the data are free of personal information.")
    return fb.facts


# ---------------------------------------------------------------- templates
def template_insights(facts, summary, needed):
    """Deterministic insights built straight from facts (no LLM). `needed` = categories to fill."""
    out = []
    by_cat = {}
    for fct in facts:
        by_cat.setdefault(fct["category"], []).append(fct)
    def ranked(pool, keywords):
        """Order facts so the most informative kinds (by keyword) come first."""
        def rank(x):
            return next((i for i, k in enumerate(keywords) if k in x["statement"]), len(keywords))
        return sorted(pool, key=rank)

    priority = {
        "data_quality": ranked(by_cat.get("data_quality", []),
                               ["code for missing", "units of measure", "letter case", "exactly 0",
                                "above the", "only one distinct", "missing for", "dominated"]),
        "distribution": ranked(by_cat.get("distribution", []), ["skewness", "ranges from"]),
        "categorical": by_cat.get("categorical", []),
        "relationship": ranked(by_cat.get("relationship", []), ["most associated", "differs by", "strongest"])
        or by_cat.get("temporal", []),
        "limitation": ranked(by_cat.get("limitation", []),
                             ["different units", "missing-value codes", "exact zeros", "why values are missing"]),
    }
    for cat in needed:
        if cat == "follow_up_question":
            q = _follow_up(summary)
            out.append({"category": cat, "text": q["text"], "fact_ids": q["fact_ids"](facts), "source": "template"})
            continue
        pool = priority.get(cat, [])
        used = {i for o in out for i in o["fact_ids"]}
        pick = next((x for x in pool if x["id"] not in used), None)
        if pick:
            out.append({"category": cat, "text": pick["statement"], "fact_ids": [pick["id"]], "source": "template"})
    return out


def _follow_up(summary):
    q, rel = summary["quality"], summary["relationships"]

    def ids_for(pred):
        return lambda facts: [x["id"] for x in facts if pred(x)][:1]

    if q["zero_inflated_columns"]:
        c = q["zero_inflated_columns"][0]["column"]
        return {"text": f"Does a value of 0 in `{c}` represent a true zero or an unrecorded value, and how would "
                        f"the distribution change if unrecorded values were excluded?",
                "fact_ids": ids_for(lambda x: c in x["columns"] and "exactly 0" in x["statement"])}
    if q["possible_sentinel_codes"]:
        s = q["possible_sentinel_codes"][0]
        return {"text": f"What does the code {s['value']} in `{s['column']}` mean according to the data publisher, "
                        f"and should it be treated as missing?",
                "fact_ids": ids_for(lambda x: s["column"] in x["columns"] and "code for missing" in x["statement"])}
    if q["high_missing_columns"]:
        c = q["high_missing_columns"][0]["column"]
        return {"text": f"Why is `{c}` missing so often, and are the rows with missing values different from the rest?",
                "fact_ids": ids_for(lambda x: c in x["columns"] and "missing for" in x["statement"])}
    if rel.get("best_group_association"):
        b = rel["best_group_association"]
        return {"text": f"What process explains the differences in `{b['measure']}` across `{b['category']}` groups?",
                "fact_ids": ids_for(lambda x: x["category"] == "relationship")}
    return {"text": "Is there a data dictionary that defines each column's meaning, units and valid range?",
            "fact_ids": ids_for(lambda x: x["category"] == "limitation")}
